from pathlib import Path

import pandas as pd

from comparator.compare import DUPLICATE_KEY, MISSING_DATA, VALUE_MISMATCH, run_comparison
from comparator.config import load_comparison_config

PROJECT_ROOT = Path(__file__).resolve().parent.parent
EMPLOYEE_DATA_CONFIG = load_comparison_config(PROJECT_ROOT / "comparisons" / "employee_data.yaml")
EMPLOYEE_TASK_CONFIG = load_comparison_config(PROJECT_ROOT / "comparisons" / "employee_task_data.yaml")


def _employee_data_frames():
    source1 = pd.DataFrame(
        [
            {
                "Employee_ID": "E001",
                "First_Name": "John",
                "Last_Name": "Doe",
                "Email": "john.doe@example.com",
                "Hire_Date": "2020-01-15",
                "Department_Code": "ENG",
            },
            {
                "Employee_ID": "E002",
                "First_Name": "Jane",
                "Last_Name": "Smith",
                "Email": "jane.smith@example.com",
                "Hire_Date": "2019-03-01",
                "Department_Code": "SAL",
            },
            {
                "Employee_ID": "E005",
                "First_Name": "Mike",
                "Last_Name": "Brown",
                "Email": "mike.brown@example.com",
                "Hire_Date": "2022-02-01",
                "Department_Code": "ENG",
            },
            {
                "Employee_ID": "E006",
                "First_Name": "Sara",
                "Last_Name": "Kim",
                "Email": "sara.kim@example.com",
                "Hire_Date": "2020-05-05",
                "Department_Code": "SAL",
            },
            {
                "Employee_ID": "E006",
                "First_Name": "Sara",
                "Last_Name": "Kim",
                "Email": "sara.kim@example.com",
                "Hire_Date": "2020-05-05",
                "Department_Code": "SAL",
            },
        ]
    )
    source2 = pd.DataFrame(
        [
            {"Employ_ID": "E007", "Email": "alice2@example.com", "Updated_At": "2023-01-01 10:00:00"},
            {"Employ_ID": "E008", "Email": "bob2@example.com", "Updated_At": "2023-02-02 11:30:00"},
        ]
    )
    target = pd.DataFrame(
        [
            {
                "EMP_ID": "E001",
                "FIRST_NM": "John",
                "LAST_NM": "Doe",
                "EMAIL_ADDR": "john.doe@example.com",
                "HIRE_DT": "2020-01-15",
                "DEPT_CD": "ENG",
                "UPDATED_AT": None,
                "SOURCE_SYSTEM": "IC",
            },
            {
                "EMP_ID": "E002",
                "FIRST_NM": "Jane",
                "LAST_NM": "Smithh",
                "EMAIL_ADDR": "jane.smith@example.com",
                "HIRE_DT": "2019-03-01",
                "DEPT_CD": "SAL",
                "UPDATED_AT": None,
                "SOURCE_SYSTEM": "IC",
            },
            {
                "EMP_ID": "E006",
                "FIRST_NM": "Sara",
                "LAST_NM": "Kim",
                "EMAIL_ADDR": "sara.kim@example.com",
                "HIRE_DT": "2020-05-05",
                "DEPT_CD": "SAL",
                "UPDATED_AT": None,
                "SOURCE_SYSTEM": "IC",
            },
            {
                "EMP_ID": "E007",
                "FIRST_NM": None,
                "LAST_NM": None,
                "EMAIL_ADDR": "alice2@example.com",
                "HIRE_DT": None,
                "DEPT_CD": None,
                "UPDATED_AT": "2023-01-01T16:00:00Z",
                "SOURCE_SYSTEM": "A1",
            },
            {
                "EMP_ID": "E011",
                "FIRST_NM": "Zoe",
                "LAST_NM": "Chen",
                "EMAIL_ADDR": "zoe.chen@example.com",
                "HIRE_DT": "2021-01-01",
                "DEPT_CD": "ENG",
                "UPDATED_AT": None,
                "SOURCE_SYSTEM": "IC",
            },
        ]
    )
    return source1, source2, target


def test_single_key_full_scenario():
    source1, source2, target = _employee_data_frames()
    result = run_comparison(
        source1_df=source1, source2_df=source2, target_df=target, config=EMPLOYEE_DATA_CONFIG
    )
    df = result.mismatch_dataframe()

    # E002: LAST_NM mismatch ("Smith" vs "Smithh")
    mismatch_rows = df[df["Remarks"] == VALUE_MISMATCH]
    assert set(mismatch_rows["Record Key"]) == {"E002"}
    assert mismatch_rows.iloc[0]["Target Column"] == "LAST_NM"

    # E005 is in source1 but not in target -> MISSING DATA, key on the source side
    missing = df[df["Remarks"] == MISSING_DATA]
    missing_keys = set(missing["Record Key"])
    assert "E005" in missing_keys  # missing in target
    assert "E011" in missing_keys  # missing in source
    e005_row = missing[missing["Record Key"] == "E005"].iloc[0]
    assert e005_row["Source Value"] == "E005"
    assert e005_row["Target Value"] is None
    e011_row = missing[missing["Record Key"] == "E011"].iloc[0]
    assert e011_row["Target Value"] == "E011"
    assert e011_row["Source Value"] is None

    # E006 is duplicated in source1 -> DUPLICATE KEY, excluded from normal matching
    duplicates = df[df["Remarks"] == DUPLICATE_KEY]
    assert set(duplicates["Record Key"]) == {"E006"}

    # E001 (full match) and E007 (match with CST->UTC datetime conversion) produce no rows at all
    assert "E001" not in set(df["Record Key"])
    assert "E007" not in set(df["Record Key"])

    summary1 = result.source_summaries["source1"]
    assert summary1.total_source_db == 5  # includes the duplicate rows
    assert summary1.duplicate_keys == 1
    assert (
        summary1.matched == 1
    )  # E001 only (E002 mismatched, E006 duplicate-excluded, E011 missing-in-source)
    assert summary1.mismatched == 1  # E002
    assert summary1.missing_in_target == 1  # E005
    assert summary1.missing_in_source == 1  # E011
    assert summary1.mismatch_counts_by_column == {"LAST_NM": 1}

    summary2 = result.source_summaries["source2"]
    assert summary2.matched == 1  # E007
    assert summary2.missing_in_target == 1  # E008 has no target row


def _employee_task_frames():
    source1 = pd.DataFrame(
        [
            {
                "Employee_ID": "E001",
                "Task_ID": "T1",
                "Task_Status": "DONE",
                "Due_Date": "2024-01-10",
                "Completed_At": "2024-01-09 08:00:00",
            },
            {
                "Employee_ID": "E001",
                "Task_ID": "T2",
                "Task_Status": "PENDING",
                "Due_Date": "2024-02-01",
                "Completed_At": None,
            },
        ]
    )
    source2 = pd.DataFrame([{"Employ_ID": "E002", "Task_ID": "T1", "Priority": "HIGH"}])
    target = pd.DataFrame(
        [
            {
                "EMP_ID": "E001",
                "TASK_ID": "T1",
                "TASK_STATUS": "DONE",
                "DUE_DT": "2024-01-10",
                "COMPLETED_TS": "2024-01-09T14:00:00Z",
                "PRIORITY": None,
                "SOURCE_SYSTEM": "IC",
            },
            {
                "EMP_ID": "E001",
                "TASK_ID": "T2",
                "TASK_STATUS": "PENDINGG",
                "DUE_DT": "2024-02-01",
                "COMPLETED_TS": None,
                "PRIORITY": None,
                "SOURCE_SYSTEM": "IC",
            },
            {
                "EMP_ID": "E002",
                "TASK_ID": "T1",
                "TASK_STATUS": None,
                "DUE_DT": None,
                "COMPLETED_TS": None,
                "PRIORITY": "HIGH",
                "SOURCE_SYSTEM": "A1",
            },
        ]
    )
    return source1, source2, target


def test_composite_key_matching():
    source1, source2, target = _employee_task_frames()
    result = run_comparison(
        source1_df=source1, source2_df=source2, target_df=target, config=EMPLOYEE_TASK_CONFIG
    )
    df = result.mismatch_dataframe()

    # (E001, T1): full match including CST->UTC conversion -> no row
    assert "E001|T1" not in set(df["Record Key"])

    # (E001, T2): TASK_STATUS mismatch -> composite key displayed as "E001|T2"
    mismatch_rows = df[df["Remarks"] == VALUE_MISMATCH]
    assert list(mismatch_rows["Record Key"]) == ["E001|T2"]
    assert mismatch_rows.iloc[0]["Target Column"] == "TASK_STATUS"

    # (E002, T1): full match on source2 side
    assert "E002|T1" not in set(df["Record Key"])

    summary1 = result.source_summaries["source1"]
    assert summary1.matched == 1
    assert summary1.mismatched == 1
    assert summary1.missing_in_target == 0
    assert summary1.missing_in_source == 0
