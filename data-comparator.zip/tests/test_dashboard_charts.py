from datetime import datetime

from dashboard.charts import (
    donut_data,
    kpi_cards,
    match_percentage_trend,
    mismatch_by_column_data,
    source_vs_target_data,
)
from dashboard.data import ReportSummary


def _report(run_timestamp: datetime, **overrides) -> ReportSummary:
    metadata = {
        "input_key_count": 12,
        "duration_seconds": 0.12,
        "mismatch_row_count": 3,
        "totals": {"source1_db": 7, "source2_db": 5, "target_source1": 6, "target_source2": 4},
        "source_summaries": {
            "source1": {
                "matched": 2,
                "mismatched": 1,
                "missing_in_target": 1,
                "missing_in_source": 1,
                "duplicate_keys": 1,
                "mismatch_counts_by_column": {"LAST_NM": 1},
                "match_percentage": 33.33,
            },
            "source2": {
                "matched": 1,
                "mismatched": 1,
                "missing_in_target": 1,
                "missing_in_source": 1,
                "duplicate_keys": 1,
                "mismatch_counts_by_column": {"EMAIL_ADDR": 1},
                "match_percentage": 25.0,
            },
        },
    }
    metadata.update(overrides)
    return ReportSummary(
        report_id="employee_data_test",
        comparison_id="employee_data",
        run_timestamp=run_timestamp,
        metadata=metadata,
        xlsx_path=None,
        json_path=None,
    )


def test_kpi_cards_includes_both_sources():
    report = _report(datetime(2026, 1, 1, 12, 0, 0))
    cards = {card["label"]: card["value"] for card in kpi_cards(report)}
    assert cards["Input key count"] == "12"
    assert cards["Source 1 match %"] == "33.3%"
    assert cards["Source 2 match %"] == "25.0%"
    assert cards["Missing records"] == "4"
    assert cards["Duplicate keys"] == "2"


def test_donut_data_sums_across_sources():
    report = _report(datetime(2026, 1, 1, 12, 0, 0))
    d = donut_data(report)
    assert d["labels"] == ["Matched", "Mismatched", "Missing", "Duplicate keys"]
    assert d["values"] == [3, 2, 4, 2]


def test_mismatch_by_column_builds_aligned_series():
    report = _report(datetime(2026, 1, 1, 12, 0, 0))
    d = mismatch_by_column_data(report)
    assert d["labels"] == ["EMAIL_ADDR", "LAST_NM"]
    assert d["series"]["Source 1"] == [0, 1]
    assert d["series"]["Source 2"] == [1, 0]


def test_source_vs_target_data():
    report = _report(datetime(2026, 1, 1, 12, 0, 0))
    d = source_vs_target_data(report)
    assert d == {"labels": ["Source 1", "Source 2"], "source_db": [7, 5], "target_db": [6, 4]}


def test_match_percentage_trend_orders_chronologically():
    older = _report(datetime(2026, 1, 1, 12, 0, 0))
    newer = _report(datetime(2026, 1, 2, 12, 0, 0))
    trend = match_percentage_trend([newer, older])
    assert trend["labels"] == ["2026-01-01 12:00", "2026-01-02 12:00"]
    assert trend["series"]["Source 1"] == [33.33, 33.33]
    assert trend["series"]["Source 2"] == [25.0, 25.0]
