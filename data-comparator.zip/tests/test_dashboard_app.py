import json
import shutil
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

import dashboard.data as dashboard_data
from dashboard.app import app

PROJECT_ROOT = Path(__file__).resolve().parent.parent


@pytest.fixture
def isolated_dashboard(tmp_path, monkeypatch):
    comparisons_dir = tmp_path / "comparisons"
    comparisons_dir.mkdir()
    shutil.copy(PROJECT_ROOT / "comparisons" / "employee_data.yaml", comparisons_dir / "employee_data.yaml")

    reports_dir = tmp_path / "reports" / "employee_data"
    reports_dir.mkdir(parents=True)
    metadata = {
        "comparison_id": "employee_data",
        "display_name": "Employee Data Comparison",
        "run_timestamp": "2026-01-01T12:00:00",
        "duration_seconds": 0.5,
        "input_key_count": 10,
        "totals": {"source1_db": 5, "source2_db": 5, "target_source1": 4, "target_source2": 4},
        "mismatch_row_count": 2,
        "excel_file": "employee_data_20260101_120000.xlsx",
        "details_csv_file": "employee_data_20260101_120000_details.csv",
        "source_summaries": {
            "source1": {
                "matched": 3,
                "mismatched": 1,
                "missing_in_target": 0,
                "missing_in_source": 0,
                "duplicate_keys": 0,
                "mismatch_counts_by_column": {"LAST_NM": 1},
                "match_percentage": 75.0,
            },
        },
    }
    json_path = reports_dir / "employee_data_20260101_120000.json"
    json_path.write_text(json.dumps(metadata), encoding="utf-8")
    (reports_dir / "employee_data_20260101_120000.xlsx").write_bytes(b"fake-xlsx-bytes")

    details_csv = reports_dir / "employee_data_20260101_120000_details.csv"
    details_csv.write_text(
        "Record Key,Source DB,Source Table,Source Column,Source Value,"
        "Target Table,Target Column,Target Value,Remarks\n"
        "E002,Source 1,HR.EMPLOYEES,Last_Name,Smith,dbo.Target_Employees,LAST_NM,Smithh,VALUE MISMATCH\n"
        "E005,Source 1,HR.EMPLOYEES,,E005,dbo.Target_Employees,,,MISSING DATA\n",
        encoding="utf-8",
    )

    monkeypatch.setattr(dashboard_data, "COMPARISONS_DIR", comparisons_dir)
    monkeypatch.setattr(dashboard_data, "REPORTS_DIR", tmp_path / "reports")
    return TestClient(app)


def test_dashboard_root_redirects_to_first_comparison(isolated_dashboard):
    resp = isolated_dashboard.get("/", follow_redirects=False)
    assert resp.status_code in (302, 307)
    assert resp.headers["location"] == "/dashboard"


def test_dashboard_renders_kpis_and_report_selector(isolated_dashboard):
    resp = isolated_dashboard.get("/dashboard/employee_data")
    assert resp.status_code == 200
    assert "Employee Data Comparison" in resp.text
    assert "2026-01-01 12:00:00" in resp.text
    assert "75.0%" in resp.text


def test_dashboard_unknown_comparison_404s(isolated_dashboard):
    resp = isolated_dashboard.get("/dashboard/does_not_exist")
    assert resp.status_code == 404


def test_api_reports_returns_chart_payload(isolated_dashboard):
    resp = isolated_dashboard.get("/api/reports/employee_data/employee_data_20260101_120000")
    assert resp.status_code == 200
    payload = resp.json()
    assert payload["donut"]["values"] == [3, 1, 0, 0]
    assert payload["download_url"] == "/download/employee_data/employee_data_20260101_120000"


def test_download_serves_the_xlsx_file(isolated_dashboard):
    resp = isolated_dashboard.get("/download/employee_data/employee_data_20260101_120000")
    assert resp.status_code == 200
    assert resp.content == b"fake-xlsx-bytes"
    assert "employee_data_20260101_120000.xlsx" in resp.headers["content-disposition"]


def test_detail_page_renders_initial_rows(isolated_dashboard):
    resp = isolated_dashboard.get("/detail/employee_data/employee_data_20260101_120000")
    assert resp.status_code == 200
    assert "Mismatch Details" in resp.text
    assert "E002" in resp.text


def test_detail_api_filters_by_remarks(isolated_dashboard):
    resp = isolated_dashboard.get(
        "/api/detail/employee_data/employee_data_20260101_120000", params={"remarks": "MISSING DATA"}
    )
    assert resp.status_code == 200
    payload = resp.json()
    assert payload["total"] == 1
    assert payload["rows"][0]["Record Key"] == "E005"


def test_detail_api_search_matches_any_column(isolated_dashboard):
    resp = isolated_dashboard.get(
        "/api/detail/employee_data/employee_data_20260101_120000", params={"search": "smithh"}
    )
    assert resp.status_code == 200
    payload = resp.json()
    assert payload["total"] == 1
    assert payload["rows"][0]["Record Key"] == "E002"


def test_detail_api_sort_desc(isolated_dashboard):
    resp = isolated_dashboard.get(
        "/api/detail/employee_data/employee_data_20260101_120000",
        params={"sort_by": "Record Key", "sort_dir": "desc"},
    )
    assert resp.status_code == 200
    rows = resp.json()["rows"]
    assert [r["Record Key"] for r in rows] == ["E005", "E002"]


def test_detail_export_csv_respects_filters(isolated_dashboard):
    resp = isolated_dashboard.get(
        "/api/detail/employee_data/employee_data_20260101_120000/export",
        params={"format": "csv", "remarks": "VALUE MISMATCH"},
    )
    assert resp.status_code == 200
    assert "employee_data_20260101_120000_filtered.csv" in resp.headers["content-disposition"]
    assert "E002" in resp.text
    assert "E005" not in resp.text
