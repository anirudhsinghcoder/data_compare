from pathlib import Path

import pytest

from comparator.config import ConfigError, load_all_comparisons, load_comparison_config, load_connections

PROJECT_ROOT = Path(__file__).resolve().parent.parent


def test_load_connections():
    connections = load_connections(PROJECT_ROOT / "config" / "connections.yaml")
    assert connections.source1.type == "oracle"
    assert connections.source2.type == "azure_sql"
    assert connections.target.always_encrypted.enabled is True


def test_load_all_sample_comparisons():
    comparisons = load_all_comparisons(PROJECT_ROOT / "comparisons")
    assert set(comparisons) == {"employee_data", "employee_task_data"}

    employee_data = comparisons["employee_data"]
    assert employee_data.keys.source1 == ["Employee_ID"]
    assert employee_data.target_source_column.mapping == {"IC": "source1", "A1": "source2"}

    employee_task_data = comparisons["employee_task_data"]
    assert employee_task_data.keys.source1 == ["Employee_ID", "Task_ID"]
    assert employee_task_data.keys.target == ["EMP_ID", "TASK_ID"]


def test_mismatched_key_arity_rejected(tmp_path):
    bad_yaml = tmp_path / "bad.yaml"
    bad_yaml.write_text(
        """
comparison_id: bad
display_name: "Bad"
input_extraction:
  source: source2
  query: "SELECT 1"
  output_dir: "input/bad"
keys:
  source1: [A, B]
  source2: [A]
  target: [A, B]
tables:
  source1: { name: t1, query: "SELECT 1 WHERE (:keys)" }
  source2: { name: t2, query: "SELECT 1 WHERE (:keys)" }
  target: { name: t3, query: "SELECT 1 WHERE (:keys)" }
target_source_column:
  name: SRC
  mapping: { IC: source1 }
column_mappings:
  source1_to_target:
    - { source_column: A, target_column: A }
""",
        encoding="utf-8",
    )
    with pytest.raises(ConfigError, match="same number of columns"):
        load_comparison_config(bad_yaml)


def test_query_without_keys_placeholder_rejected(tmp_path):
    bad_yaml = tmp_path / "bad.yaml"
    bad_yaml.write_text(
        """
comparison_id: bad
display_name: "Bad"
input_extraction:
  source: source2
  query: "SELECT 1"
  output_dir: "input/bad"
keys:
  source1: [A]
  source2: [A]
  target: [A]
tables:
  source1: { name: t1, query: "SELECT 1" }
  source2: { name: t2, query: "SELECT 1 WHERE (:keys)" }
  target: { name: t3, query: "SELECT 1 WHERE (:keys)" }
target_source_column:
  name: SRC
  mapping: { IC: source1 }
column_mappings:
  source1_to_target:
    - { source_column: A, target_column: A }
""",
        encoding="utf-8",
    )
    with pytest.raises(ConfigError, match="keys"):
        load_comparison_config(bad_yaml)
