import pandas as pd
import pytest

from comparator.config import ColumnMapping, ColumnType, KeyNormalizationConfig
from comparator.normalize import build_key_series, columns_equal, normalize_key_column


def test_normalize_key_column_trim_and_case():
    cfg = KeyNormalizationConfig(trim=True, strip_leading_zeros=False, case_insensitive=True)
    s = pd.Series([" E001 ", "e002", "E003"])
    result = normalize_key_column(s, cfg)
    assert list(result) == ["e001", "e002", "e003"]


def test_normalize_key_column_strip_leading_zeros_only_for_numeric():
    cfg = KeyNormalizationConfig(trim=True, strip_leading_zeros=True, case_insensitive=False)
    s = pd.Series(["00123", "123", "A007", "0"])
    result = normalize_key_column(s, cfg)
    assert list(result) == ["123", "123", "A007", "0"]


def test_build_key_series_single_vs_composite():
    cfg = KeyNormalizationConfig(trim=True, strip_leading_zeros=False, case_insensitive=False)
    df = pd.DataFrame({"A": ["x1", "x2"], "B": ["y1", "y2"]})
    single = build_key_series(df, ["A"], cfg)
    composite = build_key_series(df, ["A", "B"], cfg)
    assert list(single) == ["x1", "x2"]
    assert list(composite) == ["x1\x1fy1", "x2\x1fy2"]


@pytest.mark.parametrize(
    "a,b,trim,case_insensitive,expected",
    [
        ("Hello", "Hello", False, False, True),
        (" Hello ", "Hello", True, False, True),
        ("HELLO", "hello", False, True, True),
        ("HELLO", "hello", False, False, False),
    ],
)
def test_string_comparison(a, b, trim, case_insensitive, expected):
    mapping = ColumnMapping(
        source_column="s",
        target_column="t",
        type=ColumnType.STRING,
        trim=trim,
        case_insensitive=case_insensitive,
    )
    result = columns_equal(
        pd.Series([a]),
        pd.Series([b]),
        mapping,
        source_tz="America/Chicago",
        null_empty_equivalent=False,
        default_numeric_tolerance=0.0001,
    )
    assert result.iloc[0] == expected


def test_numeric_tolerance():
    mapping = ColumnMapping(source_column="s", target_column="t", type=ColumnType.NUMBER)
    result = columns_equal(
        pd.Series([1.00001, 5.0]),
        pd.Series([1.00002, 5.1]),
        mapping,
        source_tz="America/Chicago",
        null_empty_equivalent=False,
        default_numeric_tolerance=0.0001,
    )
    assert list(result) == [True, False]


def test_null_empty_equivalence():
    mapping = ColumnMapping(source_column="s", target_column="t", type=ColumnType.STRING)
    source = pd.Series([None, "", "x"])
    target = pd.Series(["", None, "x"])

    equivalent = columns_equal(
        source,
        target,
        mapping,
        source_tz="America/Chicago",
        null_empty_equivalent=True,
        default_numeric_tolerance=0.0001,
    )
    assert list(equivalent) == [True, True, True]

    not_equivalent = columns_equal(
        source,
        target,
        mapping,
        source_tz="America/Chicago",
        null_empty_equivalent=False,
        default_numeric_tolerance=0.0001,
    )
    # Without null/empty equivalence, None and "" are different values on either side.
    assert list(not_equivalent) == [False, False, True]


def test_date_normalization_ignores_format_differences():
    mapping = ColumnMapping(source_column="s", target_column="t", type=ColumnType.DATE)
    result = columns_equal(
        pd.Series(["2024-01-10", "01/10/2024"]),
        pd.Series(["2024-01-10T00:00:00", "2024-01-11"]),
        mapping,
        source_tz="America/Chicago",
        null_empty_equivalent=False,
        default_numeric_tolerance=0.0001,
    )
    assert list(result) == [True, False]


def test_datetime_timezone_conversion_standard_and_daylight_time():
    mapping = ColumnMapping(source_column="s", target_column="t", type=ColumnType.DATETIME)
    # January (CST, UTC-6) and April (CDT, UTC-5) — both should match their UTC targets.
    source = pd.Series(["2023-01-01 10:00:00", "2023-04-04 14:45:00"])
    target = pd.Series(["2023-01-01T16:00:00Z", "2023-04-04T19:45:00Z"])
    result = columns_equal(
        source,
        target,
        mapping,
        source_tz="America/Chicago",
        null_empty_equivalent=False,
        default_numeric_tolerance=0.0001,
    )
    assert list(result) == [True, True]

    mismatched_target = pd.Series(["2023-01-01T17:00:00Z", "2023-04-04T19:45:00Z"])
    result2 = columns_equal(
        source,
        mismatched_target,
        mapping,
        source_tz="America/Chicago",
        null_empty_equivalent=False,
        default_numeric_tolerance=0.0001,
    )
    assert list(result2) == [False, True]
