import pandas as pd

from dashboard.detail_data import filter_options, filter_rows, paginate, sort_rows

COLUMNS = [
    "Record Key",
    "Source DB",
    "Source Table",
    "Source Column",
    "Source Value",
    "Target Table",
    "Target Column",
    "Target Value",
    "Remarks",
]


def _df():
    return pd.DataFrame(
        [
            [
                "E001",
                "Source 1",
                "HR.EMPLOYEES",
                "Email",
                "a@x.com",
                "dbo.Target",
                "EMAIL_ADDR",
                "a@y.com",
                "VALUE MISMATCH",
            ],
            ["E002", "Source 1", "HR.EMPLOYEES", "", "E002", "dbo.Target", "", "", "MISSING DATA"],
            ["E003", "Source 2", "dbo.Employees", "", "", "dbo.Target", "", "E003", "MISSING DATA"],
            ["E004", "Source 2", "dbo.Employees", "", "E004", "dbo.Target", "", "E004", "DUPLICATE KEY"],
        ],
        columns=COLUMNS,
    )


def test_filter_by_source_db():
    result = filter_rows(_df(), source_db="Source 2")
    assert sorted(result["Record Key"]) == ["E003", "E004"]


def test_filter_by_record_key_is_case_insensitive_substring():
    result = filter_rows(_df(), record_key="e00")
    assert len(result) == 4  # every key contains "e00"
    result2 = filter_rows(_df(), record_key="004")
    assert list(result2["Record Key"]) == ["E004"]


def test_filter_by_column_checks_both_source_and_target():
    result = filter_rows(_df(), column="email_addr")
    assert list(result["Record Key"]) == ["E001"]


def test_filter_by_search_scans_every_column():
    result = filter_rows(_df(), search="a@y.com")
    assert list(result["Record Key"]) == ["E001"]


def test_sort_rows_desc():
    result = sort_rows(_df(), "Record Key", "desc")
    assert list(result["Record Key"]) == ["E004", "E003", "E002", "E001"]


def test_sort_rows_unknown_column_is_noop():
    result = sort_rows(_df(), "Nonexistent", "asc")
    assert list(result["Record Key"]) == ["E001", "E002", "E003", "E004"]


def test_paginate():
    page_df, total = paginate(_df(), page=2, page_size=2)
    assert total == 4
    assert list(page_df["Record Key"]) == ["E003", "E004"]


def test_filter_options_excludes_blanks():
    df = _df()
    options = filter_options(df)
    assert options["source_db"] == ["Source 1", "Source 2"]
    assert options["remarks"] == ["DUPLICATE KEY", "MISSING DATA", "VALUE MISMATCH"]
