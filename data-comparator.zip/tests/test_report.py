import json
from datetime import datetime
from pathlib import Path

import pandas as pd
from openpyxl import load_workbook

from comparator.compare import MISMATCH_COLUMNS, run_comparison
from comparator.config import load_comparison_config
from comparator.report import RunInfo, build_report

PROJECT_ROOT = Path(__file__).resolve().parent.parent
EMPLOYEE_DATA_CONFIG = load_comparison_config(PROJECT_ROOT / "comparisons" / "employee_data.yaml")


def _tiny_frames():
    source1 = pd.DataFrame(
        [
            {
                "Employee_ID": "E001",
                "First_Name": "John",
                "Last_Name": "Doe",
                "Email": "john@example.com",
                "Hire_Date": "2020-01-15",
                "Department_Code": "ENG",
            },
            {
                "Employee_ID": "E002",
                "First_Name": "Jane",
                "Last_Name": "Smith",
                "Email": "jane@example.com",
                "Hire_Date": "2019-03-01",
                "Department_Code": "SAL",
            },
        ]
    )
    source2 = pd.DataFrame(columns=["Employ_ID", "Email", "Updated_At"])
    target = pd.DataFrame(
        [
            {
                "EMP_ID": "E001",
                "FIRST_NM": "John",
                "LAST_NM": "Doe",
                "EMAIL_ADDR": "john@example.com",
                "HIRE_DT": "2020-01-15",
                "DEPT_CD": "ENG",
                "UPDATED_AT": None,
                "SOURCE_SYSTEM": "IC",
            },
            {
                "EMP_ID": "E002",
                "FIRST_NM": "Jane",
                "LAST_NM": "Smithh",
                "EMAIL_ADDR": "jane@example.com",
                "HIRE_DT": "2019-03-01",
                "DEPT_CD": "SAL",
                "UPDATED_AT": None,
                "SOURCE_SYSTEM": "IC",
            },
        ]
    )
    return source1, source2, target


def test_build_report_writes_xlsx_and_json(tmp_path):
    source1, source2, target = _tiny_frames()
    result = run_comparison(
        source1_df=source1, source2_df=source2, target_df=target, config=EMPLOYEE_DATA_CONFIG
    )

    run_info = RunInfo(
        started_at=datetime(2026, 1, 1, 12, 0, 0),
        duration_seconds=1.23,
        input_key_count=2,
        totals={"source1_db": 2, "source2_db": 0, "target_source1": 2, "target_source2": 0},
    )
    xlsx_path, json_path, details_csv_path = build_report(EMPLOYEE_DATA_CONFIG, result, run_info, tmp_path)

    assert xlsx_path.exists()
    assert json_path.exists()
    assert details_csv_path.exists()
    assert xlsx_path.parent.name == "employee_data"
    assert xlsx_path.name == "employee_data_20260101_120000.xlsx"
    assert details_csv_path.name == "employee_data_20260101_120000_details.csv"

    wb = load_workbook(xlsx_path)
    assert wb.sheetnames == ["Summary", "Mismatch Details"]

    detail_ws = wb["Mismatch Details"]
    header = [cell.value for cell in next(detail_ws.iter_rows(max_row=1))]
    assert header == MISMATCH_COLUMNS
    data_rows = list(detail_ws.iter_rows(min_row=2, values_only=True))
    assert len(data_rows) == 1
    assert data_rows[0][0] == "E002"
    assert data_rows[0][-1] == "VALUE MISMATCH"
    assert detail_ws.freeze_panes == "A2"
    assert len(list(detail_ws.conditional_formatting)) == 1

    summary_ws = wb["Summary"]
    assert summary_ws["A1"].value == "Employee Data Comparison"

    metadata = json.loads(json_path.read_text(encoding="utf-8"))
    assert metadata["comparison_id"] == "employee_data"
    assert metadata["mismatch_row_count"] == 1
    assert metadata["source_summaries"]["source1"]["mismatched"] == 1
    assert metadata["source_summaries"]["source1"]["matched"] == 1
    assert metadata["details_csv_file"] == details_csv_path.name

    details_df = pd.read_csv(details_csv_path, dtype=str, keep_default_na=False)
    assert list(details_df.columns) == MISMATCH_COLUMNS
    assert len(details_df) == 1
    assert details_df.iloc[0]["Record Key"] == "E002"


def test_build_report_with_no_mismatches_still_writes_header_only_sheet(tmp_path):
    source1 = pd.DataFrame(
        [
            {
                "Employee_ID": "E001",
                "First_Name": "John",
                "Last_Name": "Doe",
                "Email": "john@example.com",
                "Hire_Date": "2020-01-15",
                "Department_Code": "ENG",
            }
        ]
    )
    source2 = pd.DataFrame(columns=["Employ_ID", "Email", "Updated_At"])
    target = pd.DataFrame(
        [
            {
                "EMP_ID": "E001",
                "FIRST_NM": "John",
                "LAST_NM": "Doe",
                "EMAIL_ADDR": "john@example.com",
                "HIRE_DT": "2020-01-15",
                "DEPT_CD": "ENG",
                "UPDATED_AT": None,
                "SOURCE_SYSTEM": "IC",
            }
        ]
    )
    result = run_comparison(
        source1_df=source1, source2_df=source2, target_df=target, config=EMPLOYEE_DATA_CONFIG
    )
    run_info = RunInfo(
        started_at=datetime(2026, 1, 1, 12, 0, 0),
        duration_seconds=0.5,
        input_key_count=1,
        totals={"source1_db": 1, "source2_db": 0, "target_source1": 1, "target_source2": 0},
    )
    xlsx_path, _, _ = build_report(EMPLOYEE_DATA_CONFIG, result, run_info, tmp_path)

    wb = load_workbook(xlsx_path)
    detail_ws = wb["Mismatch Details"]
    assert detail_ws.max_row == 1
    assert len(list(detail_ws.conditional_formatting)) == 0
