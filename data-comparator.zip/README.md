# Data Comparator

A configuration-driven tool that compares records between two source
databases (Oracle, Azure SQL) and one target database (Azure SQL, with
Always Encrypted columns), writes the results to a formatted Excel report,
and serves them through a read-only web dashboard. Adding a new comparison
type is a new YAML file under `comparisons/` — no code changes.

## Contents

- [Setup](#setup)
- [Configuration](#configuration)
- [Mock / demo mode](#mock--demo-mode)
- [Running a comparison](#running-a-comparison)
- [Excel report](#excel-report)
- [Dashboard](#dashboard)
- [Detail page](#detail-page)
- [Adding a new comparison type](#adding-a-new-comparison-type)
- [Project layout](#project-layout)
- [Tests](#tests)
- [Known limitations / possible next steps](#known-limitations--possible-next-steps)

## Setup

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\pip install -r requirements.txt
copy .env.example .env
```

Fill in `.env` with real connection details, or leave it as-is and use
`--mock` everywhere below to try the whole tool without any database.

- The Oracle connector uses `oracledb` in **thin mode** — no separate Oracle
  Instant Client install needed.
- The Azure SQL connectors (source2 and target) need **ODBC Driver 18 for
  SQL Server** installed on the machine running the batch job. That's an
  OS-level driver, not something `pip install` provides.
- The target's Always Encrypted columns are decrypted via the ODBC driver's
  built-in Azure Key Vault key-store provider (`KeyStoreAuthentication=
  KeyVaultClientSecret`) — no extra Azure SDK calls at query time. Fill in
  `AKV_URL`, `AKV_CLIENT_ID`, `AKV_CLIENT_SECRET` (and `AKV_TENANT_ID`, kept
  for reference) in `.env`.

## Configuration

Two kinds of YAML, both validated at load time with clear error messages
(`comparator/config.py`, pydantic):

**`config/connections.yaml`** — one block each for `source1` (Oracle),
`source2` (Azure SQL) and `target` (Azure SQL, Always Encrypted). Holds only
*environment variable names*, never secrets — actual values come from `.env`
or the real environment (`comparator.config.resolve_env`).

**`comparisons/<id>.yaml`** — one file per comparison type. Key fields:

| Field | Meaning |
|---|---|
| `comparison_id` / `display_name` | CLI id and file-naming vs. UI label |
| `input_extraction.query` | SELECT run against source2 to get the keys to compare; result columns must match `keys.source2` |
| `input_extraction.reuse_existing_by_default` | whether to reuse the saved input CSV across runs by default |
| `timezone.source_tz` | source systems' local timezone (default `America/Chicago`, DST-aware) — target is assumed UTC |
| `keys.source1` / `keys.source2` / `keys.target` | key column name(s) per system, same arity and logical order; composite keys are just longer lists |
| `key_normalization` | trim / strip-leading-zeros / case-insensitive, for matching key values across systems |
| `tables.<role>.query` | SELECT with the literal placeholder `(:keys)` — see below |
| `target_source_column` | the target's source-system column name + its value → `source1`/`source2` mapping |
| `column_mappings.source1_to_target` / `source2_to_target` | explicit column pairs to compare, each with a `type` (`string`/`number`/`date`/`datetime`/`timestamp`) and options (`trim`, `case_insensitive`, `numeric_tolerance`) |
| `options` | `null_empty_equivalent`, default `numeric_tolerance` |
| `processing.key_batch_size` | keys per DB round-trip (further sub-batched per driver's parameter limit) |

**About `(:keys)`:** rather than `IN (...)` row-constructor syntax — which
Oracle and SQL Server don't support the same way for composite keys — every
table query's `:keys` placeholder is replaced at runtime with a bound
**OR-of-ANDs equality predicate** built from `keys.<role>` (e.g. `(COL = ?)
OR (COL = ?) OR ...`, or `(A = ? AND B = ?) OR ...` for composite keys). This
works identically for single-column and composite keys on both database
engines, so a query template just needs `WHERE (:keys)`.

**Column `type` matters.** A `number` type coerces non-numeric values to NaN
before comparing — a code-like column such as `Priority` ("HIGH"/"LOW") must
be `string`, not `number`, or every row is flagged as a false mismatch (a
real bug caught in the sample config while writing tests — see
`comparisons/employee_task_data.yaml`).

Two working samples ship in `comparisons/`: `employee_data.yaml`
(single-column key) and `employee_task_data.yaml` (composite key
`[Employee_ID, Task_ID]`).

## Mock / demo mode

No DB connections are required to try any part of the pipeline.
`demo_data/<comparison_id>/` holds `input_keys.csv`, `source1.csv`,
`source2.csv` and `target.csv` standing in for each system, hand-built to
exercise every case the engine handles: a full match, a value mismatch
(including a CST→UTC datetime conversion across both standard and daylight
time), a record missing from the target, a record missing from a source,
and a duplicate key. Pass `--mock` to the CLI to read these instead of a
real database.

## Running a comparison

```powershell
# mock mode
.\.venv\Scripts\python -m comparator.run --comparison employee_data --mock
.\.venv\Scripts\python -m comparator.run --all --mock

# against real databases (needs config/connections.yaml + .env filled in)
.\.venv\Scripts\python -m comparator.run --comparison employee_data
.\.venv\Scripts\python -m comparator.run --comparison employee_data --refresh-input
.\.venv\Scripts\python -m comparator.run --comparison employee_data --use-existing-input
```

Exit codes: `0` = success, no mismatches. `1` = mismatches found. `2` = error
(bad config, connection failure, etc.) — safe to use in a scheduler.

By default the input-key CSV is **reused** across runs (typical volumes here
run 40K–5M keys, so re-extracting every run is wasteful); pass
`--refresh-input` to force re-running the extraction query, or
`--use-existing-input` to force reuse even if a particular config's default
is to refresh. Large key lists are processed in batches
(`processing.key_batch_size`, further capped per driver's bound-parameter
limit) rather than loaded all at once.

Structured logs go to both the console and `logs/comparator_<date>.log`
(never logs credential values).

## Excel report

Each run writes to `reports/<comparison_id>/`:

- **`<comparison_id>_<timestamp>.xlsx`** — openpyxl, two sheets:
  - **Summary**: comparison name, run timestamp/duration, input key count,
    total records per system, matched/mismatched/missing/duplicate counts
    and match % per source, mismatch count per column.
  - **Mismatch Details**: `Record Key | Source DB | Source Table | Source
    Column | Source Value | Target Table | Target Column | Target Value |
    Remarks` (`VALUE MISMATCH` / `MISSING DATA` / `DUPLICATE KEY`) — frozen
    header row, auto-filter, conditional-formatting color per Remarks value.
- **`<comparison_id>_<timestamp>.json`** — the same summary numbers as
  structured data, read by the dashboard instead of re-parsing Excel.
- **`<comparison_id>_<timestamp>_details.csv`** — the Mismatch Details rows
  as CSV, read by the dashboard's Detail page for fast filter/sort/paginate.

## Dashboard

```powershell
.\.venv\Scripts\python -m uvicorn dashboard.app:app --reload
```

Open http://localhost:8000 (redirects to `/dashboard`). The dashboard reads
only the generated `reports/<comparison_id>/*.json`/`*.csv` and
`comparisons/*.yaml` — **it never connects to a source or target database**.
Generate some reports first (`--mock` works fine for trying this out).

- A **Comparison** selector navigates between comparison types; a **Report**
  selector (newest first, by run date/time) switches reports via a small
  JSON API (`/api/reports/<comparison_id>/<report_id>`) without a full page
  reload.
- KPI cards: input key count, mismatch rows, run duration, match % per
  source, missing records, duplicate keys.
- Four charts (Chart.js, **vendored locally** at
  `dashboard/static/js/vendor/chart.umd.min.js` — no CDN dependency, so this
  works on an air-gapped internal network):
  - Donut of matched / mismatched / missing / duplicate, status-colored.
  - Bar of mismatches per column, grouped by source.
  - Grouped bar of Source 1 vs. Source 2 record counts against the target.
  - Line of match % across past runs of the same comparison type.
- **Download Excel** streams the report's `.xlsx`. **Open Detail** opens the
  interactive row-level view (below).
- Dark/light theme follows the OS by default; the header toggle overrides it
  per-browser (`localStorage` — a per-viewer convenience, not shared state).
  Colors come from a validated, colorblind-safe palette
  (`dashboard/static/css/dashboard.css`): Source 1 = blue, Source 2 =
  orange, consistently across every chart, since color should follow the
  entity, not be reassigned per chart.

## Detail page

`/detail/<comparison_id>/<report_id>` — for developers/QA, the raw
Mismatch Details rows in a filterable, sortable, paginated table:

- Filters: **Source DB** and **Remarks** (dropdowns, populated from the
  report's own distinct values), **Record key** and **Column** (substring,
  case-insensitive; Column matches either the source or target column
  name), and a free-text **Search** across every column. All filters compose
  (AND'd together) and debounce on typed input.
- Click a column header to sort by it; click again to reverse direction.
- Pagination with a configurable page size (25/50/100/250).
- **Export CSV** / **Export Excel** download the *currently filtered* rows
  (not just the current page) via `/api/detail/<comparison_id>/<report_id>/export`.

This is a small hand-built table rather than DataTables/AG Grid — simpler,
no extra vendored dependency, and avoids the external-CDN issue noted below.

## Adding a new comparison type

Copy `comparisons/employee_data.yaml` (or `employee_task_data.yaml` for a
composite key), change `comparison_id`, `display_name`,
`input_extraction.query`, `keys`, `tables`, `target_source_column.mapping`
and `column_mappings`. No code changes needed — `load_all_comparisons()`
picks up every `*.yaml` file in `comparisons/`, and the dashboard discovers
it automatically from the same directory.

## Project layout

```
comparator/
  config.py        # pydantic models + YAML loaders, validation
  batching.py       # key-batch sizing + OR-of-ANDs predicate builder
  normalize.py       # value/key normalization (types, timezones, case)
  compare.py          # routing, matching, mismatch/missing/duplicate detection, summaries
  connectors/          # Connector interface, Oracle/AzureSql/Mock, build_connector()
  extract.py            # input-key extraction + per-table fetch
  report.py              # Excel + JSON + details-CSV writer
  run.py                  # batch CLI
dashboard/
  data.py           # read-only report/config access
  charts.py          # KPI + Chart.js data transforms
  detail_data.py       # load/filter/sort/paginate the details CSV
  app.py                 # FastAPI app
  routers/
    dashboard.py           # dashboard page, chart API, download
    detail.py               # detail page, row API, export
  templates/, static/        # Jinja2 templates, CSS, vendored Chart.js, JS
config/connections.yaml
comparisons/*.yaml
demo_data/, input/, reports/, logs/
tests/
```

## Tests

```powershell
.\.venv\Scripts\python -m pytest
```

45 tests: config validation, key/value normalization (including the
DST-aware timezone conversion), single- and composite-key matching,
missing/duplicate detection, summary counts, Excel/JSON/CSV report output,
mock connectors, and the dashboard's chart data, detail-row filtering, and
full FastAPI routes (via `fastapi.testclient`).

`black`/`ruff` clean (`pyproject.toml` has their config).

## Known limitations / possible next steps

- **Detail page is a hand-rolled table**, not DataTables/AG Grid as the
  original spec suggested — chosen after the preview environment silently
  blocked an external CDN request (see Chart.js vendoring above); swapping
  in a richer grid later is a template/JS change only, the API shape
  (`/api/detail/...`) wouldn't need to change.
- **No authentication** on the dashboard, per the "internal only" decision
  made at the start of this project — add an auth middleware/reverse proxy
  in front of it before exposing it beyond a trusted network.
- **Mismatch count per column** in the Summary sheet/dashboard aggregates by
  target column name; if a future comparison config reused the same target
  column name from both `source1_to_target` and `source2_to_target`, the two
  sources' counts would be shown as separate rows/series (correct) but it's
  worth knowing that's the granularity.
- The Excel writer uses a normal (non-`write_only`) `openpyxl` workbook for
  the conditional-formatting features; at the very high end of the stated
  volume range (up to ~5M records) with an unusually high mismatch rate,
  writing the Mismatch Details sheet could be memory-heavier than a
  streaming writer — not expected to matter in practice since mismatches are
  normally a small fraction of compared records, but worth a look if a real
  run ever produces millions of mismatch rows.
