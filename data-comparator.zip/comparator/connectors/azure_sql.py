"""Azure SQL connector (pyodbc + ODBC Driver 18). Supports Always Encrypted
with a column master key in Azure Key Vault, via the ODBC driver's built-in
AKV key store provider (KeyStoreAuthentication=KeyVaultClientSecret) — no
extra Azure SDK calls needed at query time.
"""

from __future__ import annotations

from collections.abc import Iterable, Sequence

import pandas as pd
import pyodbc

from ..batching import build_or_of_ands_fragment, chunk_rows, safe_batch_size
from .base import Connector

# SQL Server allows ~2100 parameters per statement; stay well clear of that.
AZURE_SQL_MAX_BOUND_PARAMS = 2000


class AzureSqlConnector(Connector):
    def __init__(
        self,
        driver: str,
        server: str,
        database: str,
        user: str,
        password: str,
        encrypt: bool = True,
        trust_server_certificate: bool = False,
        always_encrypted: bool = False,
        akv_client_id: str | None = None,
        akv_client_secret: str | None = None,
    ) -> None:
        self.driver = driver
        self.server = server
        self.database = database
        self.user = user
        self.password = password
        self.encrypt = encrypt
        self.trust_server_certificate = trust_server_certificate
        self.always_encrypted = always_encrypted
        self.akv_client_id = akv_client_id
        self.akv_client_secret = akv_client_secret
        self._conn: pyodbc.Connection | None = None

    def _connection_string(self) -> str:
        parts = [
            f"DRIVER={{{self.driver}}}",
            f"SERVER={self.server}",
            f"DATABASE={self.database}",
            f"UID={self.user}",
            f"PWD={self.password}",
            f"Encrypt={'yes' if self.encrypt else 'no'}",
            f"TrustServerCertificate={'yes' if self.trust_server_certificate else 'no'}",
        ]
        if self.always_encrypted:
            if not (self.akv_client_id and self.akv_client_secret):
                raise ValueError("always_encrypted requires akv_client_id and akv_client_secret")
            parts += [
                "ColumnEncryption=Enabled",
                "KeyStoreAuthentication=KeyVaultClientSecret",
                f"KeyStorePrincipalId={self.akv_client_id}",
                f"KeyStoreSecret={self.akv_client_secret}",
            ]
        return ";".join(parts)

    def connect(self) -> None:
        self._conn = pyodbc.connect(self._connection_string())

    def close(self) -> None:
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    def _require_conn(self) -> pyodbc.Connection:
        if self._conn is None:
            raise RuntimeError("AzureSqlConnector used before connect()")
        return self._conn

    def run_query(self, query: str) -> pd.DataFrame:
        cursor = self._require_conn().cursor()
        try:
            cursor.execute(query)
            columns = [col[0] for col in cursor.description]
            return pd.DataFrame((tuple(row) for row in cursor.fetchall()), columns=columns)
        finally:
            cursor.close()

    def fetch_by_keys(
        self,
        query_template: str,
        key_columns: Sequence[str],
        key_values: Iterable[Sequence],
        key_batch_size: int,
    ) -> pd.DataFrame:
        batch_size = safe_batch_size(key_batch_size, len(key_columns), AZURE_SQL_MAX_BOUND_PARAMS)
        frames: list[pd.DataFrame] = []
        cursor = self._require_conn().cursor()
        try:
            for batch in chunk_rows(list(key_values), batch_size):
                fragment = build_or_of_ands_fragment(key_columns, len(batch), placeholder="?")
                query = query_template.replace(":keys", fragment)
                bind_values = [value for row in batch for value in row]
                cursor.execute(query, bind_values)
                columns = [col[0] for col in cursor.description]
                frames.append(pd.DataFrame((tuple(row) for row in cursor.fetchall()), columns=columns))
        finally:
            cursor.close()
        if not frames:
            return pd.DataFrame()
        return pd.concat(frames, ignore_index=True)
