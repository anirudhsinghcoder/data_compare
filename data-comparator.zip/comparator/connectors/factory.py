"""Builds the right Connector for a role ('source1'/'source2'/'target') from
config, importing the oracledb/pyodbc-backed connectors lazily so mock mode
never requires those packages to be installed."""

from __future__ import annotations

from pathlib import Path

from ..config import AzureSqlConnectionConfig, ConnectionsConfig, OracleConnectionConfig, resolve_env
from .base import Connector
from .mock import MockConnector

Role = str  # "source1" | "source2" | "target"


def build_connector(
    name: Role,
    connections: ConnectionsConfig,
    *,
    mock_mode: bool = False,
    mock_csv_path: str | Path | None = None,
) -> Connector:
    if mock_mode:
        if mock_csv_path is None:
            raise ValueError("mock_csv_path is required when mock_mode is True")
        return MockConnector(mock_csv_path)

    config = getattr(connections, name)

    if isinstance(config, OracleConnectionConfig):
        from .oracle import OracleConnector

        return OracleConnector(
            dsn=resolve_env(config.dsn_env),
            user=resolve_env(config.user_env),
            password=resolve_env(config.password_env),
        )

    if isinstance(config, AzureSqlConnectionConfig):
        from .azure_sql import AzureSqlConnector

        akv_client_id = None
        akv_client_secret = None
        if config.always_encrypted.enabled:
            akv_client_id = resolve_env(config.always_encrypted.client_id_env)
            akv_client_secret = resolve_env(config.always_encrypted.client_secret_env)

        return AzureSqlConnector(
            driver=config.driver,
            server=resolve_env(config.server_env),
            database=resolve_env(config.database_env),
            user=resolve_env(config.user_env),
            password=resolve_env(config.password_env),
            encrypt=config.encrypt,
            trust_server_certificate=config.trust_server_certificate,
            always_encrypted=config.always_encrypted.enabled,
            akv_client_id=akv_client_id,
            akv_client_secret=akv_client_secret,
        )

    raise ValueError(f"Unsupported connection config type for '{name}': {type(config)!r}")
