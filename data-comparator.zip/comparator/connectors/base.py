"""Abstract connector interface. The comparison engine depends only on this,
so it can run against real databases or the mock connector interchangeably."""

from __future__ import annotations

import abc
from collections.abc import Iterable, Sequence

import pandas as pd


class Connector(abc.ABC):
    """Minimal interface the comparison engine needs from any data source."""

    def __enter__(self) -> Connector:
        self.connect()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    @abc.abstractmethod
    def connect(self) -> None:
        """Open the underlying connection."""

    @abc.abstractmethod
    def close(self) -> None:
        """Close the underlying connection."""

    @abc.abstractmethod
    def run_query(self, query: str) -> pd.DataFrame:
        """Run a query with no key substitution (e.g. input-ID extraction)."""

    @abc.abstractmethod
    def fetch_by_keys(
        self,
        query_template: str,
        key_columns: Sequence[str],
        key_values: Iterable[Sequence],
        key_batch_size: int,
    ) -> pd.DataFrame:
        """Run `query_template` (containing the literal placeholder ':keys')
        once per batch of `key_values`, substituting ':keys' with a bound
        OR-of-ANDs equality predicate over `key_columns`. Batches are sized
        to respect the driver's bound-parameter limit and concatenated into
        one DataFrame. Works for both single-column and composite keys.
        """
