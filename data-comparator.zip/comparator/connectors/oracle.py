"""Oracle connector (oracledb, thin mode — no Oracle Instant Client required)."""

from __future__ import annotations

from collections.abc import Iterable, Sequence

import oracledb
import pandas as pd

from ..batching import build_or_of_ands_fragment, chunk_rows, safe_batch_size
from .base import Connector

# Oracle's hard limit on expressions in a single IN-list is 1000; we build an
# OR-of-ANDs predicate instead (for composite-key support) but stay under the
# same conservative bound-parameter budget per batch.
ORACLE_MAX_BOUND_PARAMS = 1000


class OracleConnector(Connector):
    def __init__(self, dsn: str, user: str, password: str) -> None:
        self.dsn = dsn
        self.user = user
        self.password = password
        self._conn: oracledb.Connection | None = None

    def connect(self) -> None:
        self._conn = oracledb.connect(user=self.user, password=self.password, dsn=self.dsn)

    def close(self) -> None:
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    def _require_conn(self) -> oracledb.Connection:
        if self._conn is None:
            raise RuntimeError("OracleConnector used before connect()")
        return self._conn

    def run_query(self, query: str) -> pd.DataFrame:
        cursor = self._require_conn().cursor()
        try:
            cursor.execute(query)
            columns = [col[0] for col in cursor.description]
            return pd.DataFrame(cursor.fetchall(), columns=columns)
        finally:
            cursor.close()

    def fetch_by_keys(
        self,
        query_template: str,
        key_columns: Sequence[str],
        key_values: Iterable[Sequence],
        key_batch_size: int,
    ) -> pd.DataFrame:
        batch_size = safe_batch_size(key_batch_size, len(key_columns), ORACLE_MAX_BOUND_PARAMS)
        frames: list[pd.DataFrame] = []
        cursor = self._require_conn().cursor()
        try:
            for batch in chunk_rows(list(key_values), batch_size):
                fragment = build_or_of_ands_fragment(key_columns, len(batch), placeholder="?")
                fragment = _renumber_qmarks_to_oracle_binds(fragment)
                query = query_template.replace(":keys", fragment)
                bind_values = [value for row in batch for value in row]
                cursor.execute(query, bind_values)
                columns = [col[0] for col in cursor.description]
                frames.append(pd.DataFrame(cursor.fetchall(), columns=columns))
        finally:
            cursor.close()
        if not frames:
            return pd.DataFrame()
        return pd.concat(frames, ignore_index=True)


def _renumber_qmarks_to_oracle_binds(fragment: str) -> str:
    """oracledb binds are positional ':1', ':2', ... — not '?' (pyodbc style)."""
    parts = fragment.split("?")
    out = [parts[0]]
    for i, part in enumerate(parts[1:], start=1):
        out.append(f":{i}")
        out.append(part)
    return "".join(out)
