"""Demo-mode connector: reads a single CSV file standing in for either an
input-extraction result or a full source/target table. Used so the whole
pipeline (extract -> compare -> report -> dashboard) can run with no DB
access, against data under demo_data/<comparison_id>/.
"""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from pathlib import Path

import pandas as pd

from .base import Connector


class MockConnector(Connector):
    def __init__(self, csv_path: str | Path) -> None:
        self.csv_path = Path(csv_path)
        self._df: pd.DataFrame | None = None

    def connect(self) -> None:
        if not self.csv_path.exists():
            raise FileNotFoundError(f"Mock data file not found: {self.csv_path}")
        self._df = pd.read_csv(self.csv_path, dtype=str, keep_default_na=False)

    def close(self) -> None:
        self._df = None

    def _require_loaded(self) -> pd.DataFrame:
        if self._df is None:
            raise RuntimeError("MockConnector used before connect()")
        return self._df

    def run_query(self, query: str) -> pd.DataFrame:
        # Demo mode ignores the actual SQL text; the CSV content is the result.
        return self._require_loaded().copy()

    def fetch_by_keys(
        self,
        query_template: str,
        key_columns: Sequence[str],
        key_values: Iterable[Sequence],
        key_batch_size: int,
    ) -> pd.DataFrame:
        df = self._require_loaded()
        missing = [col for col in key_columns if col not in df.columns]
        if missing:
            raise ValueError(f"{self.csv_path} is missing key column(s): {missing}")

        wanted = {tuple(str(v).strip() for v in row) for row in key_values}
        if not wanted:
            return df.iloc[0:0].copy()

        key_tuples = df[list(key_columns)].astype(str).apply(lambda s: s.str.strip())
        mask = key_tuples.apply(tuple, axis=1).isin(wanted)
        return df[mask].copy()
