"""Batch CLI entrypoint.

    python -m comparator.run --comparison employee_data
    python -m comparator.run --comparison employee_data --mock
    python -m comparator.run --all --use-existing-input
    python -m comparator.run --comparison employee_data --refresh-input

Exit codes: 0 = success, no mismatches. 1 = mismatches found. 2 = error.
"""

from __future__ import annotations

import argparse
import logging
import sys
import time
from datetime import datetime
from pathlib import Path

from dotenv import load_dotenv

from .compare import route_target_by_source, run_comparison
from .config import ComparisonConfig, ConfigError, ConnectionsConfig, load_all_comparisons, load_connections
from .extract import extract_input_keys, fetch_table, key_values_from_input
from .report import RunInfo, build_report

logger = logging.getLogger("comparator")


def _configure_logging(log_dir: Path, level: str) -> None:
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / f"comparator_{datetime.now():%Y%m%d}.log"
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[logging.FileHandler(log_file, encoding="utf-8"), logging.StreamHandler(sys.stdout)],
        force=True,
    )


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run a config-driven data comparison.")
    target_group = parser.add_mutually_exclusive_group(required=True)
    target_group.add_argument("--comparison", help="comparison_id to run (see comparisons/*.yaml)")
    target_group.add_argument("--all", action="store_true", help="run every comparison in comparisons/")

    input_group = parser.add_mutually_exclusive_group()
    input_group.add_argument(
        "--refresh-input",
        action="store_true",
        help="re-run the input-extraction query even if an input file already exists",
    )
    input_group.add_argument(
        "--use-existing-input",
        action="store_true",
        help="reuse the existing input file even if the config defaults to refreshing it",
    )

    parser.add_argument(
        "--mock", action="store_true", help="run against demo_data/<comparison_id>/ CSVs, no DB connections"
    )
    parser.add_argument("--comparisons-dir", default=Path("comparisons"), type=Path)
    parser.add_argument("--connections-file", default=Path("config/connections.yaml"), type=Path)
    parser.add_argument("--reports-dir", default=Path("reports"), type=Path)
    parser.add_argument("--demo-dir", default=Path("demo_data"), type=Path)
    parser.add_argument("--log-dir", default=Path("logs"), type=Path)
    parser.add_argument("--log-level", default="INFO")
    return parser.parse_args(argv)


def run_one(
    comparison_id: str,
    config: ComparisonConfig,
    connections: ConnectionsConfig | None,
    args: argparse.Namespace,
) -> int:
    run_started_at = datetime.now()
    t0 = time.monotonic()
    logger.info("=== Starting comparison '%s' (%s) ===", comparison_id, config.display_name)
    try:
        mock_dir = (args.demo_dir / comparison_id) if args.mock else None
        reuse_input: bool | None = None
        if args.refresh_input:
            reuse_input = False
        elif args.use_existing_input:
            reuse_input = True

        input_df = extract_input_keys(
            config, connections, mock_mode=args.mock, mock_dir=mock_dir, reuse_input=reuse_input
        )
        key_values = key_values_from_input(config, input_df)
        logger.info("Input key count: %d", len(key_values))

        source1_df = fetch_table(
            "source1", config, connections, key_values, mock_mode=args.mock, mock_dir=mock_dir
        )
        source2_df = fetch_table(
            "source2", config, connections, key_values, mock_mode=args.mock, mock_dir=mock_dir
        )
        target_df = fetch_table(
            "target", config, connections, key_values, mock_mode=args.mock, mock_dir=mock_dir
        )

        result = run_comparison(
            source1_df=source1_df, source2_df=source2_df, target_df=target_df, config=config
        )

        target_by_source = route_target_by_source(target_df, config.target_source_column)
        totals = {
            "source1_db": len(source1_df),
            "source2_db": len(source2_df),
            "target_source1": len(target_by_source["source1"]),
            "target_source2": len(target_by_source["source2"]),
        }
        duration_seconds = time.monotonic() - t0
        run_info = RunInfo(
            started_at=run_started_at,
            duration_seconds=duration_seconds,
            input_key_count=len(key_values),
            totals=totals,
        )
        xlsx_path, _json_path, _details_csv_path = build_report(config, result, run_info, args.reports_dir)

        mismatch_count = len(result.rows)
        logger.info(
            "Comparison '%s' finished in %.2fs - %d mismatch row(s). Report: %s",
            comparison_id,
            duration_seconds,
            mismatch_count,
            xlsx_path,
        )
        return 1 if mismatch_count > 0 else 0
    except Exception:
        logger.exception("Comparison '%s' failed", comparison_id)
        return 2


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    _configure_logging(args.log_dir, args.log_level)
    load_dotenv()

    try:
        all_configs = load_all_comparisons(args.comparisons_dir)
    except ConfigError as exc:
        logger.error("Config error: %s", exc)
        return 2

    if args.all:
        comparison_ids = list(all_configs)
    else:
        if args.comparison not in all_configs:
            logger.error(
                "Unknown comparison_id '%s'. Available: %s", args.comparison, ", ".join(sorted(all_configs))
            )
            return 2
        comparison_ids = [args.comparison]

    connections: ConnectionsConfig | None = None
    if not args.mock:
        try:
            connections = load_connections(args.connections_file)
        except ConfigError as exc:
            logger.error("Config error: %s", exc)
            return 2

    worst_code = 0
    for comparison_id in comparison_ids:
        code = run_one(comparison_id, all_configs[comparison_id], connections, args)
        worst_code = max(worst_code, code)
    return worst_code


if __name__ == "__main__":
    sys.exit(main())
