"""Comparison engine: routes target rows by source system, matches records on
(possibly composite) keys, and reports value mismatches, missing records and
duplicate keys. Vectorized with pandas merges — no per-row Python loops.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import pandas as pd

from .config import (
    ColumnMapping,
    ComparisonConfig,
    KeyNormalizationConfig,
    OptionsConfig,
    TargetSourceColumnConfig,
)
from .normalize import build_key_series, columns_equal, display_key

VALUE_MISMATCH = "VALUE MISMATCH"
MISSING_DATA = "MISSING DATA"
DUPLICATE_KEY = "DUPLICATE KEY"

MISMATCH_COLUMNS = [
    "Record Key",
    "Source DB",
    "Source Table",
    "Source Column",
    "Source Value",
    "Target Table",
    "Target Column",
    "Target Value",
    "Remarks",
]


@dataclass
class SourceSummary:
    source_label: str
    total_source_db: int = 0
    total_target_db: int = 0
    matched: int = 0
    mismatched: int = 0
    missing_in_target: int = 0
    missing_in_source: int = 0
    duplicate_keys: int = 0
    mismatch_counts_by_column: dict[str, int] = field(default_factory=dict)

    @property
    def total_compared(self) -> int:
        return self.matched + self.mismatched + self.missing_in_target + self.missing_in_source

    @property
    def match_percentage(self) -> float:
        if self.total_compared == 0:
            return 0.0
        return round(self.matched / self.total_compared * 100, 2)


@dataclass
class ComparisonResult:
    rows: list[dict[str, Any]]
    source_summaries: dict[str, SourceSummary]

    def mismatch_dataframe(self) -> pd.DataFrame:
        return pd.DataFrame(self.rows, columns=MISMATCH_COLUMNS)


def route_target_by_source(
    target_df: pd.DataFrame, target_source_column: TargetSourceColumnConfig
) -> dict[str, pd.DataFrame]:
    """Split target rows by SOURCE_SYSTEM into {'source1': df, 'source2': df}."""
    col = target_source_column.name
    result: dict[str, pd.DataFrame] = {"source1": target_df.iloc[0:0], "source2": target_df.iloc[0:0]}
    for raw_value, source_name in target_source_column.mapping.items():
        subset = target_df[target_df[col] == raw_value]
        result[source_name] = subset
    return result


def _find_duplicate_keys(key_series: pd.Series) -> set[str]:
    dup_mask = key_series.duplicated(keep=False)
    return set(key_series[dup_mask].unique())


def compare_one_source(
    *,
    source_df: pd.DataFrame,
    target_subset_df: pd.DataFrame,
    key_columns_source: list[str],
    key_columns_target: list[str],
    column_mappings: list[ColumnMapping],
    key_normalization: KeyNormalizationConfig,
    options: OptionsConfig,
    source_tz: str,
    source_label: str,
    source_table_name: str,
    target_table_name: str,
) -> tuple[list[dict[str, Any]], SourceSummary]:
    summary = SourceSummary(
        source_label=source_label,
        total_source_db=len(source_df),
        total_target_db=len(target_subset_df),
    )
    rows: list[dict[str, Any]] = []

    src_key = build_key_series(source_df, key_columns_source, key_normalization)
    tgt_key = build_key_series(target_subset_df, key_columns_target, key_normalization)

    duplicate_keys = _find_duplicate_keys(src_key) | _find_duplicate_keys(tgt_key)
    for dup_key in duplicate_keys:
        src_row = source_df[src_key == dup_key]
        tgt_row = target_subset_df[tgt_key == dup_key]
        record_key = (
            display_key(src_row.iloc[0], key_columns_source)
            if len(src_row) > 0
            else display_key(tgt_row.iloc[0], key_columns_target)
        )
        rows.append(
            {
                "Record Key": record_key,
                "Source DB": source_label,
                "Source Table": source_table_name,
                "Source Column": None,
                "Source Value": record_key if len(src_row) > 0 else None,
                "Target Table": target_table_name,
                "Target Column": None,
                "Target Value": record_key if len(tgt_row) > 0 else None,
                "Remarks": DUPLICATE_KEY,
            }
        )
    summary.duplicate_keys = len(duplicate_keys)

    not_dup_src = ~src_key.isin(duplicate_keys)
    not_dup_tgt = ~tgt_key.isin(duplicate_keys)
    source_clean = source_df[not_dup_src].reset_index(drop=True)
    target_clean = target_subset_df[not_dup_tgt].reset_index(drop=True)
    src_key_clean = src_key[not_dup_src].reset_index(drop=True)
    tgt_key_clean = tgt_key[not_dup_tgt].reset_index(drop=True)

    src_lookup = pd.DataFrame({"_key": src_key_clean, "_src_idx": source_clean.index})
    tgt_lookup = pd.DataFrame({"_key": tgt_key_clean, "_tgt_idx": target_clean.index})
    merged = src_lookup.merge(tgt_lookup, on="_key", how="outer")

    matched_mask = merged["_src_idx"].notna() & merged["_tgt_idx"].notna()
    missing_in_target_mask = merged["_src_idx"].notna() & merged["_tgt_idx"].isna()
    missing_in_source_mask = merged["_src_idx"].isna() & merged["_tgt_idx"].notna()

    missing_in_target = merged[missing_in_target_mask]
    for src_idx in missing_in_target["_src_idx"].astype(int):
        record_key = display_key(source_clean.iloc[src_idx], key_columns_source)
        rows.append(
            {
                "Record Key": record_key,
                "Source DB": source_label,
                "Source Table": source_table_name,
                "Source Column": None,
                "Source Value": record_key,
                "Target Table": target_table_name,
                "Target Column": None,
                "Target Value": None,
                "Remarks": MISSING_DATA,
            }
        )
    summary.missing_in_target = len(missing_in_target)

    missing_in_source = merged[missing_in_source_mask]
    for tgt_idx in missing_in_source["_tgt_idx"].astype(int):
        record_key = display_key(target_clean.iloc[tgt_idx], key_columns_target)
        rows.append(
            {
                "Record Key": record_key,
                "Source DB": source_label,
                "Source Table": source_table_name,
                "Source Column": None,
                "Source Value": None,
                "Target Table": target_table_name,
                "Target Column": None,
                "Target Value": record_key,
                "Remarks": MISSING_DATA,
            }
        )
    summary.missing_in_source = len(missing_in_source)

    matched = merged[matched_mask]
    if len(matched) > 0:
        matched_src_idx = matched["_src_idx"].astype(int).to_numpy()
        matched_tgt_idx = matched["_tgt_idx"].astype(int).to_numpy()
        matched_src_df = source_clean.iloc[matched_src_idx].reset_index(drop=True)
        matched_tgt_df = target_clean.iloc[matched_tgt_idx].reset_index(drop=True)

        mismatched_keys: set[int] = set()
        for mapping in column_mappings:
            equal = columns_equal(
                matched_src_df[mapping.source_column],
                matched_tgt_df[mapping.target_column],
                mapping,
                source_tz=source_tz,
                null_empty_equivalent=options.null_empty_equivalent,
                default_numeric_tolerance=options.numeric_tolerance,
            )
            mismatch_positions = (~equal).to_numpy().nonzero()[0]
            if len(mismatch_positions) == 0:
                continue
            summary.mismatch_counts_by_column[mapping.target_column] = summary.mismatch_counts_by_column.get(
                mapping.target_column, 0
            ) + len(mismatch_positions)
            for pos in mismatch_positions:
                mismatched_keys.add(pos)
                record_key = display_key(matched_src_df.iloc[pos], key_columns_source)
                rows.append(
                    {
                        "Record Key": record_key,
                        "Source DB": source_label,
                        "Source Table": source_table_name,
                        "Source Column": mapping.source_column,
                        "Source Value": matched_src_df.iloc[pos][mapping.source_column],
                        "Target Table": target_table_name,
                        "Target Column": mapping.target_column,
                        "Target Value": matched_tgt_df.iloc[pos][mapping.target_column],
                        "Remarks": VALUE_MISMATCH,
                    }
                )
        summary.mismatched = len(mismatched_keys)
        summary.matched = len(matched) - len(mismatched_keys)
    else:
        summary.matched = 0

    return rows, summary


def run_comparison(
    *,
    source1_df: pd.DataFrame,
    source2_df: pd.DataFrame,
    target_df: pd.DataFrame,
    config: ComparisonConfig,
) -> ComparisonResult:
    target_by_source = route_target_by_source(target_df, config.target_source_column)

    all_rows: list[dict[str, Any]] = []
    summaries: dict[str, SourceSummary] = {}

    branches = [
        (
            "source1",
            source1_df,
            config.keys.source1,
            config.column_mappings.source1_to_target,
            "Source 1",
            config.tables.source1.name,
        ),
        (
            "source2",
            source2_df,
            config.keys.source2,
            config.column_mappings.source2_to_target,
            "Source 2",
            config.tables.source2.name,
        ),
    ]
    for (
        source_name,
        source_df,
        key_columns_source,
        column_mappings,
        source_label,
        source_table_name,
    ) in branches:
        if not column_mappings:
            continue
        rows, summary = compare_one_source(
            source_df=source_df,
            target_subset_df=target_by_source[source_name],
            key_columns_source=key_columns_source,
            key_columns_target=config.keys.target,
            column_mappings=column_mappings,
            key_normalization=config.key_normalization,
            options=config.options,
            source_tz=config.timezone.source_tz,
            source_label=source_label,
            source_table_name=source_table_name,
            target_table_name=config.tables.target.name,
        )
        all_rows.extend(rows)
        summaries[source_name] = summary

    return ComparisonResult(rows=all_rows, source_summaries=summaries)
