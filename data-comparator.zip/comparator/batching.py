"""Key-batching helpers shared by all connectors.

Keys are compared via a bound OR-of-ANDs equality predicate rather than
IN(...) row constructors, so composite keys work identically on Oracle and
SQL Server. This module only decides how many key tuples go in one batch;
each connector turns a batch into its own dialect's placeholder syntax.
"""

from __future__ import annotations

from collections.abc import Iterable, Iterator, Sequence


def chunk_rows(rows: Iterable[Sequence], batch_size: int) -> Iterator[list[Sequence]]:
    """Split `rows` into lists of at most `batch_size` items."""
    if batch_size <= 0:
        raise ValueError("batch_size must be positive")
    batch: list[Sequence] = []
    for row in rows:
        batch.append(row)
        if len(batch) == batch_size:
            yield batch
            batch = []
    if batch:
        yield batch


def safe_batch_size(requested_batch_size: int, num_key_columns: int, max_bound_params: int) -> int:
    """Clamp a requested key-batch size so batch_size * num_key_columns stays
    within a driver's bound-parameter limit (Oracle: 1000 total expressions
    in practice for this predicate style; SQL Server: ~2100 params)."""
    if num_key_columns <= 0:
        raise ValueError("num_key_columns must be positive")
    max_rows_for_param_limit = max(1, max_bound_params // num_key_columns)
    return max(1, min(requested_batch_size, max_rows_for_param_limit))


def build_or_of_ands_fragment(key_columns: Sequence[str], num_rows: int, placeholder: str) -> str:
    """Build e.g. '(COL_A = ? AND COL_B = ?) OR (COL_A = ? AND COL_B = ?)' for
    `num_rows` key tuples over `key_columns`, using `placeholder` ('?' for
    pyodbc qmark style, ':N' style handled by the Oracle connector itself)."""
    row_clause = " AND ".join(f"{col} = {placeholder}" for col in key_columns)
    return " OR ".join(f"({row_clause})" for _ in range(num_rows))
