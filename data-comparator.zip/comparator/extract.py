"""Input-key extraction (against source2) and per-table data fetch for a
comparison run. All DB access for a run goes through this module.
"""

from __future__ import annotations

import logging
from pathlib import Path

import pandas as pd

from .config import ComparisonConfig, ConnectionsConfig
from .connectors import build_connector

logger = logging.getLogger(__name__)


def input_csv_path(config: ComparisonConfig) -> Path:
    return Path(config.input_extraction.output_dir) / f"{config.comparison_id}_input.csv"


def extract_input_keys(
    config: ComparisonConfig,
    connections: ConnectionsConfig | None,
    *,
    mock_mode: bool = False,
    mock_dir: Path | None = None,
    reuse_input: bool | None = None,
) -> pd.DataFrame:
    """Fetch (or reuse) the keys to compare for this run. Returns a
    DataFrame whose columns include config.keys.source2 (the extraction
    query must select those column names)."""
    path = input_csv_path(config)
    should_reuse = config.input_extraction.reuse_existing_by_default if reuse_input is None else reuse_input

    if should_reuse and path.exists():
        logger.info("Reusing existing input file: %s", path)
        df = pd.read_csv(path, dtype=str, keep_default_na=False)
    else:
        logger.info("Running input-extraction query against source2 for '%s'", config.comparison_id)
        mock_csv_path = (mock_dir / "input_keys.csv") if mock_mode else None
        with build_connector(
            "source2", connections, mock_mode=mock_mode, mock_csv_path=mock_csv_path
        ) as conn:
            df = conn.run_query(config.input_extraction.query)
        path.parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(path, index=False)
        logger.info("Saved %d input key(s) to %s", len(df), path)

    missing = [c for c in config.keys.source2 if c not in df.columns]
    if missing:
        raise ValueError(
            f"Input extraction result for '{config.comparison_id}' is missing key column(s) {missing}. "
            f"The extraction query must return columns named exactly like keys.source2: {config.keys.source2}"
        )
    return df


def key_values_from_input(config: ComparisonConfig, input_df: pd.DataFrame) -> list[tuple]:
    """Key tuples in canonical (source1/source2/target-aligned) order."""
    return list(input_df[config.keys.source2].itertuples(index=False, name=None))


def fetch_table(
    role: str,
    config: ComparisonConfig,
    connections: ConnectionsConfig | None,
    key_values: list[tuple],
    *,
    mock_mode: bool = False,
    mock_dir: Path | None = None,
) -> pd.DataFrame:
    """role is one of 'source1', 'source2', 'target'."""
    table_cfg = getattr(config.tables, role)
    key_columns = getattr(config.keys, role)
    mock_csv_path = (mock_dir / f"{role}.csv") if mock_mode else None

    with build_connector(role, connections, mock_mode=mock_mode, mock_csv_path=mock_csv_path) as conn:
        df = conn.fetch_by_keys(
            query_template=table_cfg.query,
            key_columns=key_columns,
            key_values=key_values,
            key_batch_size=config.processing.key_batch_size,
        )
    logger.info("Fetched %d row(s) from %s table '%s'", len(df), role, table_cfg.name)
    return df
