"""Read-only data layer for the dashboard.

Reads reports/<comparison_id>/*.json (run metadata written by
comparator.report) and comparisons/*.yaml (for display names). Never opens a
connection to a source or target database — that happens only in the batch
CLI (comparator.run).
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from comparator.config import ComparisonConfig, load_all_comparisons

PROJECT_ROOT = Path(__file__).resolve().parent.parent
COMPARISONS_DIR = PROJECT_ROOT / "comparisons"
REPORTS_DIR = PROJECT_ROOT / "reports"


@dataclass
class ReportSummary:
    report_id: str
    comparison_id: str
    run_timestamp: datetime
    metadata: dict
    xlsx_path: Path
    json_path: Path


def list_comparisons() -> dict[str, ComparisonConfig]:
    if not COMPARISONS_DIR.exists():
        return {}
    return load_all_comparisons(COMPARISONS_DIR)


def list_reports(comparison_id: str) -> list[ReportSummary]:
    """Newest first."""
    comp_dir = REPORTS_DIR / comparison_id
    if not comp_dir.exists():
        return []
    reports = []
    for json_path in sorted(comp_dir.glob("*.json")):
        metadata = json.loads(json_path.read_text(encoding="utf-8"))
        xlsx_path = json_path.with_suffix(".xlsx")
        reports.append(
            ReportSummary(
                report_id=json_path.stem,
                comparison_id=comparison_id,
                run_timestamp=datetime.fromisoformat(metadata["run_timestamp"]),
                metadata=metadata,
                xlsx_path=xlsx_path,
                json_path=json_path,
            )
        )
    reports.sort(key=lambda r: r.run_timestamp, reverse=True)
    return reports


def get_report(comparison_id: str, report_id: str) -> ReportSummary | None:
    return next((r for r in list_reports(comparison_id) if r.report_id == report_id), None)
