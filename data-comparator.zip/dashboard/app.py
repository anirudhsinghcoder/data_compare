"""FastAPI dashboard app.

Reads only reports/*.json run metadata and comparisons/*.yaml display names
(see dashboard/data.py) — it never opens a connection to a source or target
database. Run with:

    uvicorn dashboard.app:app --reload
"""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles

from .routers import dashboard as dashboard_router
from .routers import detail as detail_router

BASE_DIR = Path(__file__).resolve().parent

app = FastAPI(title="Data Comparator Dashboard")
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
app.include_router(dashboard_router.router)
app.include_router(detail_router.router)


@app.get("/")
def root() -> RedirectResponse:
    return RedirectResponse(url="/dashboard")
