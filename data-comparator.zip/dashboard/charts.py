"""Transforms report run-metadata into the KPI cards and Chart.js-ready
structures the dashboard template and the /api/reports endpoint both use.
"""

from __future__ import annotations

from .data import ReportSummary

SOURCE_KEYS = ["source1", "source2"]
SOURCE_LABELS = {"source1": "Source 1", "source2": "Source 2"}


def kpi_cards(report: ReportSummary) -> list[dict]:
    meta = report.metadata
    summaries = meta["source_summaries"]

    cards = [
        {"label": "Input key count", "value": f"{meta['input_key_count']:,}"},
        {"label": "Mismatch rows", "value": f"{meta['mismatch_row_count']:,}"},
        {"label": "Run duration", "value": f"{meta['duration_seconds']:.1f}s"},
    ]
    for key in SOURCE_KEYS:
        s = summaries.get(key)
        if s:
            cards.append({"label": f"{SOURCE_LABELS[key]} match %", "value": f"{s['match_percentage']:.1f}%"})

    total_missing = sum(
        s.get("missing_in_target", 0) + s.get("missing_in_source", 0) for s in summaries.values()
    )
    total_duplicates = sum(s.get("duplicate_keys", 0) for s in summaries.values())
    cards.append({"label": "Missing records", "value": f"{total_missing:,}"})
    cards.append({"label": "Duplicate keys", "value": f"{total_duplicates:,}"})
    return cards


def donut_data(report: ReportSummary) -> dict:
    summaries = report.metadata["source_summaries"]
    matched = sum(s.get("matched", 0) for s in summaries.values())
    mismatched = sum(s.get("mismatched", 0) for s in summaries.values())
    missing = sum(s.get("missing_in_target", 0) + s.get("missing_in_source", 0) for s in summaries.values())
    duplicates = sum(s.get("duplicate_keys", 0) for s in summaries.values())
    return {
        "labels": ["Matched", "Mismatched", "Missing", "Duplicate keys"],
        "values": [matched, mismatched, missing, duplicates],
    }


def mismatch_by_column_data(report: ReportSummary) -> dict:
    summaries = report.metadata["source_summaries"]
    entries = []
    for key in SOURCE_KEYS:
        s = summaries.get(key)
        if not s:
            continue
        for column, count in s.get("mismatch_counts_by_column", {}).items():
            entries.append((SOURCE_LABELS[key], column, count))

    labels = sorted({column for _, column, _ in entries})
    series = {label: [0] * len(labels) for label in SOURCE_LABELS.values()}
    for source_label, column, count in entries:
        series[source_label][labels.index(column)] = count
    return {"labels": labels, "series": series}


def source_vs_target_data(report: ReportSummary) -> dict:
    totals = report.metadata["totals"]
    return {
        "labels": ["Source 1", "Source 2"],
        "source_db": [totals.get("source1_db", 0), totals.get("source2_db", 0)],
        "target_db": [totals.get("target_source1", 0), totals.get("target_source2", 0)],
    }


def match_percentage_trend(reports: list[ReportSummary]) -> dict:
    ordered = sorted(reports, key=lambda r: r.run_timestamp)
    labels = [r.run_timestamp.strftime("%Y-%m-%d %H:%M") for r in ordered]
    series: dict[str, list[float | None]] = {label: [] for label in SOURCE_LABELS.values()}
    for r in ordered:
        summaries = r.metadata["source_summaries"]
        for key, label in SOURCE_LABELS.items():
            s = summaries.get(key)
            series[label].append(s["match_percentage"] if s else None)
    return {"labels": labels, "series": series}


def report_payload(report: ReportSummary, all_reports: list[ReportSummary]) -> dict:
    """Everything the dashboard page needs for one selected report."""
    return {
        "report_id": report.report_id,
        "run_timestamp": report.run_timestamp.strftime("%Y-%m-%d %H:%M:%S"),
        "kpis": kpi_cards(report),
        "donut": donut_data(report),
        "mismatch_by_column": mismatch_by_column_data(report),
        "source_vs_target": source_vs_target_data(report),
        "trend": match_percentage_trend(all_reports),
        "download_url": f"/download/{report.comparison_id}/{report.report_id}",
        "detail_url": f"/detail/{report.comparison_id}/{report.report_id}",
    }
