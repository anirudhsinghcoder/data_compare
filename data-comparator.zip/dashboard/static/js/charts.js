(function () {
  var chartInstances = {};

  function cssVar(name) {
    return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  }

  function destroyAll() {
    Object.keys(chartInstances).forEach(function (key) {
      if (chartInstances[key]) chartInstances[key].destroy();
    });
    chartInstances = {};
  }

  function axisScale(extra) {
    return Object.assign(
      {
        ticks: { color: cssVar("--text-muted") },
        grid: { color: cssVar("--gridline"), drawTicks: false },
        border: { color: cssVar("--baseline") },
      },
      extra || {}
    );
  }

  function legendOptions(extra) {
    return Object.assign(
      { labels: { color: cssVar("--text-secondary"), usePointStyle: true } },
      extra || {}
    );
  }

  function renderDonut(payload) {
    var ctx = document.getElementById("chart-donut");
    if (!ctx) return;
    var colors = [
      cssVar("--status-good"),
      cssVar("--status-critical"),
      cssVar("--status-serious"),
      cssVar("--status-warning"),
    ];
    chartInstances.donut = new Chart(ctx, {
      type: "doughnut",
      data: {
        labels: payload.donut.labels,
        datasets: [
          {
            data: payload.donut.values,
            backgroundColor: colors,
            borderColor: cssVar("--surface-1"),
            borderWidth: 2,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: "60%",
        plugins: { legend: legendOptions({ position: "bottom" }) },
      },
    });
  }

  function renderMismatchByColumn(payload) {
    var ctx = document.getElementById("chart-mismatch-column");
    if (!ctx) return;
    var d = payload.mismatch_by_column;
    var hasData = d.labels.length > 0;
    var labels = hasData ? d.labels : ["No mismatches"];
    var series = hasData ? d.series : { "Source 1": [0], "Source 2": [0] };

    chartInstances.mismatchColumn = new Chart(ctx, {
      type: "bar",
      data: {
        labels: labels,
        datasets: Object.keys(series).map(function (sourceLabel) {
          return {
            label: sourceLabel,
            data: series[sourceLabel],
            backgroundColor: sourceLabel === "Source 1" ? cssVar("--series-source1") : cssVar("--series-source2"),
            borderRadius: 4,
            maxBarThickness: 24,
            categoryPercentage: 0.6,
            barPercentage: 0.9,
          };
        }),
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: legendOptions() },
        scales: {
          x: axisScale(),
          y: axisScale({ beginAtZero: true, ticks: { color: cssVar("--text-muted"), precision: 0 } }),
        },
      },
    });
  }

  function renderSourceVsTarget(payload) {
    var ctx = document.getElementById("chart-source-vs-target");
    if (!ctx) return;
    var d = payload.source_vs_target;
    chartInstances.sourceVsTarget = new Chart(ctx, {
      type: "bar",
      data: {
        labels: d.labels,
        datasets: [
          {
            label: "Records in source DB",
            data: d.source_db,
            backgroundColor: cssVar("--series-source1"),
            borderRadius: 4,
            maxBarThickness: 24,
          },
          {
            label: "Records in target DB",
            data: d.target_db,
            backgroundColor: cssVar("--series-source2"),
            borderRadius: 4,
            maxBarThickness: 24,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: legendOptions() },
        scales: { x: axisScale(), y: axisScale({ beginAtZero: true }) },
      },
    });
  }

  function renderTrend(payload) {
    var ctx = document.getElementById("chart-trend");
    if (!ctx) return;
    var d = payload.trend;
    chartInstances.trend = new Chart(ctx, {
      type: "line",
      data: {
        labels: d.labels,
        datasets: Object.keys(d.series).map(function (sourceLabel) {
          var color = sourceLabel === "Source 1" ? cssVar("--series-source1") : cssVar("--series-source2");
          return {
            label: sourceLabel,
            data: d.series[sourceLabel],
            borderColor: color,
            backgroundColor: color,
            borderWidth: 2,
            pointRadius: 4,
            pointHoverRadius: 5,
            tension: 0.25,
            spanGaps: true,
          };
        }),
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: legendOptions() },
        scales: {
          x: axisScale(),
          y: axisScale({
            beginAtZero: true,
            max: 100,
            ticks: {
              color: cssVar("--text-muted"),
              callback: function (value) {
                return value + "%";
              },
            },
          }),
        },
      },
    });
  }

  window.DashboardCharts = {
    render: function (payload) {
      destroyAll();
      if (!payload) return;
      renderDonut(payload);
      renderMismatchByColumn(payload);
      renderSourceVsTarget(payload);
      renderTrend(payload);
    },
    destroyAll: destroyAll,
  };
})();
