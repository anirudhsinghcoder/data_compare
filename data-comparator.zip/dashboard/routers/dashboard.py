from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.templating import Jinja2Templates

from .. import charts, data

BASE_DIR = Path(__file__).resolve().parent.parent
templates = Jinja2Templates(directory=BASE_DIR / "templates")

router = APIRouter()


@router.get("/dashboard", response_class=HTMLResponse)
def dashboard_root(request: Request) -> HTMLResponse:
    comparisons = data.list_comparisons()
    if not comparisons:
        return templates.TemplateResponse(request, "empty.html")
    first_id = sorted(comparisons)[0]
    return dashboard_view(request, first_id, report=None)


@router.get("/dashboard/{comparison_id}", response_class=HTMLResponse)
def dashboard_view(request: Request, comparison_id: str, report: str | None = None) -> HTMLResponse:
    comparisons = data.list_comparisons()
    if comparison_id not in comparisons:
        raise HTTPException(status_code=404, detail=f"Unknown comparison_id '{comparison_id}'")

    reports = data.list_reports(comparison_id)
    selected = None
    if reports:
        selected = next((r for r in reports if r.report_id == report), reports[0]) if report else reports[0]

    context = {
        "comparisons": comparisons,
        "comparison_id": comparison_id,
        "comparison_name": comparisons[comparison_id].display_name,
        "reports": reports,
        "selected_report": selected,
        "payload": charts.report_payload(selected, reports) if selected else None,
    }
    return templates.TemplateResponse(request, "dashboard.html", context)


@router.get("/api/reports/{comparison_id}/{report_id}")
def report_data(comparison_id: str, report_id: str) -> dict:
    reports = data.list_reports(comparison_id)
    selected = next((r for r in reports if r.report_id == report_id), None)
    if not selected:
        raise HTTPException(status_code=404, detail="Report not found")
    return charts.report_payload(selected, reports)


@router.get("/download/{comparison_id}/{report_id}")
def download_report(comparison_id: str, report_id: str) -> FileResponse:
    selected = data.get_report(comparison_id, report_id)
    if not selected or not selected.xlsx_path.exists():
        raise HTTPException(status_code=404, detail="Report file not found")
    return FileResponse(
        selected.xlsx_path,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        filename=selected.xlsx_path.name,
    )
