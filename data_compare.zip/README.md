# Data Comparator

A configuration-driven tool that compares records between one source
database and one target database (both Azure SQL, authenticated as an Azure
AD service principal; the target has Always Encrypted columns), writes the
results to a formatted Excel report plus a pipe-separated "update" file, and
serves them through a read-only web dashboard. Adding a new comparison type
is a new YAML file under `comparisons/` — no code changes.

## Contents

- [Setup](#setup)
- [Configuration](#configuration)
- [Mock / demo mode](#mock--demo-mode)
- [Running a comparison](#running-a-comparison)
- [Outputs](#outputs)
- [Dashboard](#dashboard)
- [Detail page](#detail-page)
- [Adding a new comparison type](#adding-a-new-comparison-type)
- [Project layout](#project-layout)
- [Tests](#tests)
- [Known limitations / possible next steps](#known-limitations--possible-next-steps)

## Setup

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\pip install -r requirements.txt
copy .env.example .env
```

Fill in `.env` with real connection details, or leave it as-is and use
`--mock` everywhere below to try the whole tool without any database.

- Source and target are both Azure SQL, reached through **ODBC Driver 18
  for SQL Server** — an OS-level driver, not something `pip install`
  provides, so it needs to be installed on the machine running the batch
  job.
- Both connections authenticate as an **Azure AD service principal** (an
  app registration's client ID + secret, optionally scoped to a tenant),
  not a SQL login — `Authentication=ActiveDirectoryServicePrincipal` in the
  ODBC connection string.
- The target's Always Encrypted columns are decrypted via the ODBC driver's
  built-in Azure Key Vault key-store provider
  (`KeyStoreAuthentication=KeyVaultClientSecret`), **reusing the target's
  own service principal** — that app registration needs `get`/`unwrapKey`
  on the column master key in Key Vault. No extra Azure SDK calls happen at
  query time, and there's no separate Key Vault credential to configure.

## Configuration

Two kinds of YAML, both validated at load time with clear error messages
(`comparator/config.py`, pydantic):

**`config/connections.yaml`** — one block each for `source` and `target`
(both Azure SQL). Holds only *environment variable names*, never secrets —
actual values come from `.env` or the real environment
(`comparator.config.resolve_env`):

```yaml
source:
  type: azure_sql
  server_env: SOURCE_SERVER
  database_env: SOURCE_DATABASE
  service_principal:
    client_id_env: SOURCE_SP_CLIENT_ID
    client_secret_env: SOURCE_SP_CLIENT_SECRET
    tenant_id_env: SOURCE_SP_TENANT_ID   # optional
target:
  type: azure_sql
  server_env: TARGET_SERVER
  database_env: TARGET_DATABASE
  service_principal: { ... }
  always_encrypted:
    enabled: true
    key_vault_url_env: AKV_URL   # reuses target's service_principal above
```

**`comparisons/<id>.yaml`** — one file per comparison type. Key fields:

| Field | Meaning |
|---|---|
| `comparison_id` / `display_name` | CLI id and file-naming vs. UI label |
| `input_extraction.query` | SELECT run against the **source** to get the keys to compare; result columns must match `keys.source` |
| `input_extraction.reuse_existing_by_default` | whether to reuse the saved input CSV across runs by default |
| `timezone.source_tz` | source's local timezone (default `America/Chicago`, DST-aware) — target is assumed UTC |
| `keys.source` / `keys.target` | key column name(s) per system, same arity and logical order; composite keys are just longer lists |
| `key_normalization` | trim / strip-leading-zeros / case-insensitive, for matching key values between source and target |
| `tables.<role>.query` | SELECT with the literal placeholder `(:keys)` — see below |
| `column_mappings` | explicit source/target column pairs to compare, each with a `type` (`string`/`number`/`date`/`datetime`/`timestamp`) and options (`trim`, `case_insensitive`, `numeric_tolerance`) |
| `options` | `null_empty_equivalent`, default `numeric_tolerance` |
| `processing.key_batch_size` | keys per DB round-trip (further sub-batched per driver's parameter limit) |

**About `(:keys)`:** rather than `IN (...)` row-constructor syntax, every
table query's `:keys` placeholder is replaced at runtime with a bound
**OR-of-ANDs equality predicate** built from `keys.<role>` (e.g. `(COL = ?)
OR (COL = ?) OR ...`, or `(A = ? AND B = ?) OR ...` for composite keys),
batched to respect Azure SQL's per-statement parameter limit. This works
identically for single-column and composite keys, so a query template just
needs `WHERE (:keys)`.

**Column `type` matters.** A `number` type coerces non-numeric values to NaN
before comparing — a code-like column such as `Priority` ("HIGH"/"LOW") must
be `string`, not `number`, or every row is flagged as a false mismatch (a
real bug caught in the sample config while writing tests — see
`comparisons/employee_task_data.yaml`).

Two working samples ship in `comparisons/`: `employee_data.yaml`
(single-column key) and `employee_task_data.yaml` (composite key
`[Employee_ID, Task_ID]`).

## Mock / demo mode

No DB connections are required to try any part of the pipeline.
`demo_data/<comparison_id>/` holds `input_keys.csv`, `source.csv` and
`target.csv` standing in for the source and target databases, hand-built to
exercise every case the engine handles: a full match, a value mismatch
(including a CST→UTC datetime conversion across both standard and daylight
time), a record missing from the target, a record missing from the source,
and a duplicate key. Pass `--mock` to the CLI to read these instead of a
real database.

## Running a comparison

```powershell
# mock mode
.\.venv\Scripts\python -m comparator.run --comparison employee_data --mock
.\.venv\Scripts\python -m comparator.run --all --mock

# against real databases (needs config/connections.yaml + .env filled in)
.\.venv\Scripts\python -m comparator.run --comparison employee_data
.\.venv\Scripts\python -m comparator.run --comparison employee_data --refresh-input
.\.venv\Scripts\python -m comparator.run --comparison employee_data --use-existing-input
```

Exit codes: `0` = success, no mismatches. `1` = mismatches found. `2` = error
(bad config, connection failure, etc.) — safe to use in a scheduler.

By default the input-key CSV is **reused** across runs (typical volumes here
run 40K–5M keys, extracted from the source itself, so re-extracting every
run is wasteful); pass `--refresh-input` to force re-running the extraction
query, or `--use-existing-input` to force reuse even if a particular
config's default is to refresh. Large key lists are processed in batches
(`processing.key_batch_size`, further capped per driver's bound-parameter
limit) rather than loaded all at once.

Structured logs go to both the console and `logs/comparator_<date>.log`
(never logs credential values).

## Outputs

Each run writes to `reports/<comparison_id>/`:

- **`<comparison_id>_<timestamp>.xlsx`** — openpyxl, two sheets:
  - **Summary**: comparison name, run timestamp/duration, input key count,
    total records in the source and target DBs, matched/mismatched/missing/
    duplicate counts and match %, mismatch count per column.
  - **Mismatch Details**: `Source DB Key | Source Table | Source Column |
    Source Value | Target DB Key | Target Table | Target Column | Target
    Value | Remarks` (`VALUE MISMATCH` / `MISSING DATA` / `DUPLICATE KEY`) —
    frozen header row, auto-filter, conditional-formatting color per
    Remarks value. `Source DB Key`/`Target DB Key` are the record's key
    column value(s) on each side, pipe-joined for a composite key (e.g.
    `E001|T1`), and blank on whichever side the record doesn't exist.
- **`<comparison_id>_<timestamp>.json`** — the same summary numbers as
  structured data, read by the dashboard instead of re-parsing Excel.
- **`<comparison_id>_<timestamp>_details.csv`** — the Mismatch Details rows
  as CSV, read by the dashboard's Detail page for fast filter/sort/paginate.
- **`<comparison_id>_<timestamp>_update.txt`** — pipe-separated, **mismatched
  records only** (not missing/duplicate), one row per record:
  `Source_Column_Key_1[...N] | Target_Column_Key_1[...N] | Mismatched_Columns | Action`,
  where `Mismatched_Columns` is a comma-separated list of every target
  column that differed for that record and `Action` is always literally
  `UPDATE`. Meant to drive a downstream process that updates just those
  columns in the target. One `Source_Column_Key_N`/`Target_Column_Key_N`
  pair per key column — a single-column key produces `_1` only; a
  composite key produces `_1`, `_2`, etc. Built by
  `comparator.report.build_update_pipe_rows`.

## Dashboard

```powershell
.\.venv\Scripts\python -m uvicorn dashboard.app:app --reload
```

Open http://localhost:8000 (redirects to `/dashboard`). The dashboard reads
only the generated `reports/<comparison_id>/*.json`/`*.csv` and
`comparisons/*.yaml` — **it never connects to the source or target
database**. Generate some reports first (`--mock` works fine for trying
this out).

- A **Comparison** selector navigates between comparison types; a **Report**
  selector (newest first, by run date/time) switches reports via a small
  JSON API (`/api/reports/<comparison_id>/<report_id>`) without a full page
  reload.
- KPI cards: input key count, match %, mismatch rows, records to update,
  missing records, duplicate keys, run duration.
- Four charts (Chart.js, **vendored locally** at
  `dashboard/static/js/vendor/chart.umd.min.js` — no CDN dependency, so this
  works on an air-gapped internal network):
  - Donut of matched / mismatched / missing / duplicate, status-colored.
  - Bar of mismatches per column.
  - Bar of source vs. target record counts.
  - Line of match % across past runs of the same comparison type.
- **Download Excel** streams the `.xlsx`. **Download Update File** streams
  the pipe-separated `_update.txt`. **Open Detail** opens the interactive
  row-level view (below).
- Dark/light theme follows the OS by default; the header toggle overrides it
  per-browser (`localStorage` — a per-viewer convenience, not shared state).
  Colors come from a validated, colorblind-safe palette
  (`dashboard/static/css/dashboard.css`).

## Detail page

`/detail/<comparison_id>/<report_id>` — for developers/QA, the raw
Mismatch Details rows in a filterable, sortable, paginated table:

- Filters: **Remarks** (dropdown, populated from the report's own distinct
  values), **DB key** (substring, case-insensitive, matches either
  `Source DB Key` or `Target DB Key`) and **Column** (substring,
  case-insensitive; matches either the source or target column name), and a
  free-text **Search** across every column. All filters compose (AND'd
  together) and debounce on typed input.
- Click a column header to sort by it; click again to reverse direction.
- Pagination with a configurable page size (25/50/100/250).
- **Download Update File** / **Download Excel** (the whole report).
  **Export CSV** / **Export Excel** download the *currently filtered* rows
  (not just the current page) via `/api/detail/<comparison_id>/<report_id>/export`.

This is a small hand-built table rather than DataTables/AG Grid — simpler,
no extra vendored dependency, and avoids the external-CDN issue noted below.

## Adding a new comparison type

Copy `comparisons/employee_data.yaml` (or `employee_task_data.yaml` for a
composite key), change `comparison_id`, `display_name`,
`input_extraction.query`, `keys`, `tables` and `column_mappings`. No code
changes needed — `load_all_comparisons()` picks up every `*.yaml` file in
`comparisons/`, and the dashboard discovers it automatically from the same
directory.

## Project layout

```
comparator/
  config.py        # pydantic models + YAML loaders, validation
  batching.py       # key-batch sizing + OR-of-ANDs predicate builder
  normalize.py       # value/key normalization (types, timezones, case)
  compare.py          # single-source matching, mismatch/missing/duplicate detection, summary
  connectors/          # Connector interface, AzureSql (service principal), Mock, build_connector()
  extract.py            # input-key extraction (from source) + per-table fetch
  report.py              # Excel + JSON + details-CSV + update-pipe-file writer
  run.py                  # batch CLI
dashboard/
  data.py           # read-only report/config access
  charts.py          # KPI + Chart.js data transforms
  detail_data.py       # load/filter/sort/paginate the details CSV
  app.py                 # FastAPI app
  routers/
    dashboard.py           # dashboard page, chart API, downloads
    detail.py               # detail page, row API, export
  templates/, static/        # Jinja2 templates, CSS, vendored Chart.js, JS
config/connections.yaml
comparisons/*.yaml
demo_data/, input/, reports/, logs/
tests/
```

## Tests

```powershell
.\.venv\Scripts\python -m pytest
```

49 tests: config validation, key/value normalization (including the
DST-aware timezone conversion), single- and composite-key matching,
missing/duplicate detection, summary counts, Excel/JSON/CSV/update-pipe-file
output, mock connectors, and the dashboard's chart data, detail-row
filtering, and full FastAPI routes (via `fastapi.testclient`).

`black`/`ruff` clean (`pyproject.toml` has their config).

## Known limitations / possible next steps

- **Detail page is a hand-rolled table**, not DataTables/AG Grid as the
  original spec suggested — chosen after the preview environment silently
  blocked an external CDN request (see Chart.js vendoring above); swapping
  in a richer grid later is a template/JS change only, the API shape
  (`/api/detail/...`) wouldn't need to change.
- **No authentication** on the dashboard, per the "internal only" decision
  made at the start of this project — add an auth middleware/reverse proxy
  in front of it before exposing it beyond a trusted network.
- **Service principal tenant.** `tenant_id_env` is optional; when set, the
  connector authenticates as `<client_id>@<tenant_id>`. Leave it unset if
  the app registration lives in the same tenant as the Azure SQL server.
- **Update file scope.** The `_update.txt` pipe file only covers `VALUE
  MISMATCH` records (existing rows with differing columns) — missing and
  duplicate records are not in it, since "UPDATE" doesn't describe what to
  do with those (they'd need an INSERT/DELETE/manual-review workflow,
  which this file doesn't attempt to drive).
- The Excel writer uses a normal (non-`write_only`) `openpyxl` workbook for
  the conditional-formatting features; at the very high end of the stated
  volume range (up to ~5M records) with an unusually high mismatch rate,
  writing the Mismatch Details sheet could be memory-heavier than a
  streaming writer — not expected to matter in practice since mismatches are
  normally a small fraction of compared records, but worth a look if a real
  run ever produces millions of mismatch rows.
