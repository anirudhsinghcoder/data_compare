import json
from datetime import datetime
from pathlib import Path

import pandas as pd
from openpyxl import load_workbook

from comparator.compare import MISMATCH_COLUMNS, run_comparison
from comparator.config import load_comparison_config
from comparator.report import RunInfo, build_report

PROJECT_ROOT = Path(__file__).resolve().parent.parent
EMPLOYEE_DATA_CONFIG = load_comparison_config(PROJECT_ROOT / "comparisons" / "employee_data.yaml")
EMPLOYEE_TASK_CONFIG = load_comparison_config(PROJECT_ROOT / "comparisons" / "employee_task_data.yaml")


def _tiny_frames():
    source = pd.DataFrame(
        [
            {
                "Employee_ID": "E001",
                "First_Name": "John",
                "Last_Name": "Doe",
                "Email": "john@example.com",
                "Hire_Date": "2020-01-15",
                "Department_Code": "ENG",
                "Last_Modified": "2023-01-01 10:00:00",
            },
            {
                "Employee_ID": "E002",
                "First_Name": "Jane",
                "Last_Name": "Smith",
                "Email": "jane@example.com",
                "Hire_Date": "2019-03-01",
                "Department_Code": "SAL",
                "Last_Modified": "2023-01-01 10:00:00",
            },
        ]
    )
    target = pd.DataFrame(
        [
            {
                "EMP_ID": "E001",
                "FIRST_NM": "John",
                "LAST_NM": "Doe",
                "EMAIL_ADDR": "john@example.com",
                "HIRE_DT": "2020-01-15",
                "DEPT_CD": "ENG",
                "UPDATED_AT": "2023-01-01T16:00:00Z",
            },
            {
                "EMP_ID": "E002",
                "FIRST_NM": "Jane",
                "LAST_NM": "Smithh",
                "EMAIL_ADDR": "jane@example.com",
                "HIRE_DT": "2019-03-01",
                "DEPT_CD": "SAL",
                "UPDATED_AT": "2023-01-01T16:00:00Z",
            },
        ]
    )
    return source, target


def test_build_report_writes_xlsx_json_csv_and_update_file(tmp_path):
    source, target = _tiny_frames()
    result = run_comparison(source_df=source, target_df=target, config=EMPLOYEE_DATA_CONFIG)

    run_info = RunInfo(
        started_at=datetime(2026, 1, 1, 12, 0, 0),
        duration_seconds=1.23,
        input_key_count=2,
        totals={"source_db": 2, "target_db": 2},
    )
    xlsx_path, json_path, details_csv_path, update_pipe_path = build_report(
        EMPLOYEE_DATA_CONFIG, result, run_info, tmp_path
    )

    assert xlsx_path.exists()
    assert json_path.exists()
    assert details_csv_path.exists()
    assert update_pipe_path.exists()
    assert xlsx_path.parent.name == "employee_data"
    assert xlsx_path.name == "employee_data_20260101_120000.xlsx"
    assert details_csv_path.name == "employee_data_20260101_120000_details.csv"
    assert update_pipe_path.name == "employee_data_20260101_120000_update.txt"

    wb = load_workbook(xlsx_path)
    assert wb.sheetnames == ["Summary", "Mismatch Details"]

    detail_ws = wb["Mismatch Details"]
    header = [cell.value for cell in next(detail_ws.iter_rows(max_row=1))]
    assert header == MISMATCH_COLUMNS
    data_rows = list(detail_ws.iter_rows(min_row=2, values_only=True))
    assert len(data_rows) == 1
    assert data_rows[0][0] == "E002"  # Source DB Key
    assert data_rows[0][-1] == "VALUE MISMATCH"
    assert detail_ws.freeze_panes == "A2"
    assert len(list(detail_ws.conditional_formatting)) == 1

    summary_ws = wb["Summary"]
    assert summary_ws["A1"].value == "Employee Data Comparison"

    metadata = json.loads(json_path.read_text(encoding="utf-8"))
    assert metadata["comparison_id"] == "employee_data"
    assert metadata["mismatch_row_count"] == 1
    assert metadata["update_row_count"] == 1
    assert metadata["summary"]["mismatched"] == 1
    assert metadata["summary"]["matched"] == 1
    assert metadata["details_csv_file"] == details_csv_path.name
    assert metadata["update_pipe_file"] == update_pipe_path.name

    details_df = pd.read_csv(details_csv_path, dtype=str, keep_default_na=False)
    assert list(details_df.columns) == MISMATCH_COLUMNS
    assert len(details_df) == 1
    assert details_df.iloc[0]["Source DB Key"] == "E002"

    update_df = pd.read_csv(update_pipe_path, sep="|", dtype=str, keep_default_na=False)
    assert list(update_df.columns) == [
        "Source_Column_Key_1",
        "Target_Column_Key_1",
        "Mismatched_Columns",
        "Action",
    ]
    assert len(update_df) == 1
    row = update_df.iloc[0]
    assert row["Source_Column_Key_1"] == "E002"
    assert row["Target_Column_Key_1"] == "E002"
    assert row["Mismatched_Columns"] == "LAST_NM"
    assert row["Action"] == "UPDATE"


def test_build_report_with_no_mismatches_still_writes_header_only_outputs(tmp_path):
    source = pd.DataFrame(
        [
            {
                "Employee_ID": "E001",
                "First_Name": "John",
                "Last_Name": "Doe",
                "Email": "john@example.com",
                "Hire_Date": "2020-01-15",
                "Department_Code": "ENG",
                "Last_Modified": "2023-01-01 10:00:00",
            }
        ]
    )
    target = pd.DataFrame(
        [
            {
                "EMP_ID": "E001",
                "FIRST_NM": "John",
                "LAST_NM": "Doe",
                "EMAIL_ADDR": "john@example.com",
                "HIRE_DT": "2020-01-15",
                "DEPT_CD": "ENG",
                "UPDATED_AT": "2023-01-01T16:00:00Z",
            }
        ]
    )
    result = run_comparison(source_df=source, target_df=target, config=EMPLOYEE_DATA_CONFIG)
    run_info = RunInfo(
        started_at=datetime(2026, 1, 1, 12, 0, 0),
        duration_seconds=0.5,
        input_key_count=1,
        totals={"source_db": 1, "target_db": 1},
    )
    xlsx_path, _json_path, _details_csv_path, update_pipe_path = build_report(
        EMPLOYEE_DATA_CONFIG, result, run_info, tmp_path
    )

    wb = load_workbook(xlsx_path)
    detail_ws = wb["Mismatch Details"]
    assert detail_ws.max_row == 1
    assert len(list(detail_ws.conditional_formatting)) == 0

    update_df = pd.read_csv(update_pipe_path, sep="|", dtype=str, keep_default_na=False)
    assert len(update_df) == 0
    assert list(update_df.columns) == [
        "Source_Column_Key_1",
        "Target_Column_Key_1",
        "Mismatched_Columns",
        "Action",
    ]


def test_update_pipe_file_composite_key(tmp_path):
    source = pd.DataFrame(
        [
            {
                "Employee_ID": "E001",
                "Task_ID": "T2",
                "Task_Status": "PENDING",
                "Due_Date": "2024-02-01",
                "Completed_At": None,
                "Priority": "HIGH",
            }
        ]
    )
    target = pd.DataFrame(
        [
            {
                "EMP_ID": "E001",
                "TASK_ID": "T2",
                "TASK_STATUS": "PENDINGG",
                "DUE_DT": "2024-02-01",
                "COMPLETED_TS": None,
                "PRIORITY": "HIGH",
            }
        ]
    )
    result = run_comparison(source_df=source, target_df=target, config=EMPLOYEE_TASK_CONFIG)
    run_info = RunInfo(
        started_at=datetime(2026, 1, 1, 12, 0, 0),
        duration_seconds=0.1,
        input_key_count=1,
        totals={"source_db": 1, "target_db": 1},
    )
    _xlsx, _json, _details, update_pipe_path = build_report(EMPLOYEE_TASK_CONFIG, result, run_info, tmp_path)

    update_df = pd.read_csv(update_pipe_path, sep="|", dtype=str, keep_default_na=False)
    assert list(update_df.columns) == [
        "Source_Column_Key_1",
        "Source_Column_Key_2",
        "Target_Column_Key_1",
        "Target_Column_Key_2",
        "Mismatched_Columns",
        "Action",
    ]
    assert len(update_df) == 1
    row = update_df.iloc[0]
    assert row["Source_Column_Key_1"] == "E001"
    assert row["Source_Column_Key_2"] == "T2"
    assert row["Target_Column_Key_1"] == "E001"
    assert row["Target_Column_Key_2"] == "T2"
    assert row["Mismatched_Columns"] == "TASK_STATUS"
    assert row["Action"] == "UPDATE"
