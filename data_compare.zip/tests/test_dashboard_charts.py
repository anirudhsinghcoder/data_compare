from datetime import datetime

from dashboard.charts import (
    donut_data,
    kpi_cards,
    match_percentage_trend,
    mismatch_by_column_data,
    source_vs_target_data,
)
from dashboard.data import ReportSummary


def _report(run_timestamp: datetime, **overrides) -> ReportSummary:
    metadata = {
        "input_key_count": 12,
        "duration_seconds": 0.12,
        "mismatch_row_count": 3,
        "update_row_count": 2,
        "totals": {"source_db": 7, "target_db": 6},
        "summary": {
            "matched": 3,
            "mismatched": 2,
            "missing_in_target": 1,
            "missing_in_source": 1,
            "duplicate_keys": 1,
            "mismatch_counts_by_column": {"LAST_NM": 1, "EMAIL_ADDR": 1},
            "match_percentage": 42.86,
        },
    }
    metadata.update(overrides)
    return ReportSummary(
        report_id="employee_data_test",
        comparison_id="employee_data",
        run_timestamp=run_timestamp,
        metadata=metadata,
        xlsx_path=None,
        json_path=None,
        update_pipe_path=None,
    )


def test_kpi_cards():
    report = _report(datetime(2026, 1, 1, 12, 0, 0))
    cards = {card["label"]: card["value"] for card in kpi_cards(report)}
    assert cards["Input key count"] == "12"
    assert cards["Match %"] == "42.9%"
    assert cards["Mismatch rows"] == "3"
    assert cards["Records to update"] == "2"
    assert cards["Missing records"] == "2"
    assert cards["Duplicate keys"] == "1"


def test_donut_data():
    report = _report(datetime(2026, 1, 1, 12, 0, 0))
    d = donut_data(report)
    assert d["labels"] == ["Matched", "Mismatched", "Missing", "Duplicate keys"]
    assert d["values"] == [3, 2, 2, 1]


def test_mismatch_by_column_data():
    report = _report(datetime(2026, 1, 1, 12, 0, 0))
    d = mismatch_by_column_data(report)
    assert d["labels"] == ["EMAIL_ADDR", "LAST_NM"]
    assert d["values"] == [1, 1]


def test_source_vs_target_data():
    report = _report(datetime(2026, 1, 1, 12, 0, 0))
    d = source_vs_target_data(report)
    assert d == {"labels": ["Source DB", "Target DB"], "values": [7, 6]}


def test_match_percentage_trend_orders_chronologically():
    older = _report(datetime(2026, 1, 1, 12, 0, 0))
    newer = _report(datetime(2026, 1, 2, 12, 0, 0))
    trend = match_percentage_trend([newer, older])
    assert trend["labels"] == ["2026-01-01 12:00", "2026-01-02 12:00"]
    assert trend["values"] == [42.86, 42.86]
