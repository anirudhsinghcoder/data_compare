from pathlib import Path

import pytest

from comparator.config import ConfigError, load_all_comparisons, load_comparison_config, load_connections

PROJECT_ROOT = Path(__file__).resolve().parent.parent


def test_load_connections():
    connections = load_connections(PROJECT_ROOT / "config" / "connections.yaml")
    assert connections.source.type == "azure_sql"
    assert connections.target.type == "azure_sql"
    assert connections.source.service_principal.client_id_env == "SOURCE_SP_CLIENT_ID"
    assert connections.target.always_encrypted.enabled is True


def test_load_all_sample_comparisons():
    comparisons = load_all_comparisons(PROJECT_ROOT / "comparisons")
    assert set(comparisons) == {"employee_data", "employee_task_data"}

    employee_data = comparisons["employee_data"]
    assert employee_data.keys.source == ["Employee_ID"]
    assert employee_data.keys.target == ["EMP_ID"]

    employee_task_data = comparisons["employee_task_data"]
    assert employee_task_data.keys.source == ["Employee_ID", "Task_ID"]
    assert employee_task_data.keys.target == ["EMP_ID", "TASK_ID"]


def test_mismatched_key_arity_rejected(tmp_path):
    bad_yaml = tmp_path / "bad.yaml"
    bad_yaml.write_text(
        """
comparison_id: bad
display_name: "Bad"
input_extraction:
  query: "SELECT 1"
  output_dir: "input/bad"
keys:
  source: [A, B]
  target: [A]
tables:
  source: { name: t1, query: "SELECT 1 WHERE (:keys)" }
  target: { name: t3, query: "SELECT 1 WHERE (:keys)" }
column_mappings:
  - { source_column: A, target_column: A }
""",
        encoding="utf-8",
    )
    with pytest.raises(ConfigError, match="same number of columns"):
        load_comparison_config(bad_yaml)


def test_query_without_keys_placeholder_rejected(tmp_path):
    bad_yaml = tmp_path / "bad.yaml"
    bad_yaml.write_text(
        """
comparison_id: bad
display_name: "Bad"
input_extraction:
  query: "SELECT 1"
  output_dir: "input/bad"
keys:
  source: [A]
  target: [A]
tables:
  source: { name: t1, query: "SELECT 1" }
  target: { name: t3, query: "SELECT 1 WHERE (:keys)" }
column_mappings:
  - { source_column: A, target_column: A }
""",
        encoding="utf-8",
    )
    with pytest.raises(ConfigError, match="keys"):
        load_comparison_config(bad_yaml)


def test_empty_column_mappings_rejected(tmp_path):
    bad_yaml = tmp_path / "bad.yaml"
    bad_yaml.write_text(
        """
comparison_id: bad
display_name: "Bad"
input_extraction:
  query: "SELECT 1"
  output_dir: "input/bad"
keys:
  source: [A]
  target: [A]
tables:
  source: { name: t1, query: "SELECT 1 WHERE (:keys)" }
  target: { name: t3, query: "SELECT 1 WHERE (:keys)" }
column_mappings: []
""",
        encoding="utf-8",
    )
    with pytest.raises(ConfigError):
        load_comparison_config(bad_yaml)
