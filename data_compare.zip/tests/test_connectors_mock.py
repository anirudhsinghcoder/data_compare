from pathlib import Path

from comparator.connectors import MockConnector

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEMO_DIR = PROJECT_ROOT / "demo_data" / "employee_data"
DEMO_TASK_DIR = PROJECT_ROOT / "demo_data" / "employee_task_data"


def test_run_query_returns_full_csv():
    with MockConnector(DEMO_DIR / "input_keys.csv") as conn:
        df = conn.run_query("SELECT Employee_ID FROM dbo.Employees")
    assert list(df.columns) == ["Employee_ID"]
    assert len(df) == 9


def test_fetch_by_keys_single_column():
    with MockConnector(DEMO_DIR / "source.csv") as conn:
        df = conn.fetch_by_keys(
            query_template="SELECT * FROM dbo.Employees WHERE (:keys)",
            key_columns=["Employee_ID"],
            key_values=[("E001",), ("E003",), ("E999",)],
            key_batch_size=50000,
        )
    assert sorted(df["Employee_ID"]) == ["E001", "E003"]


def test_fetch_by_keys_composite():
    with MockConnector(DEMO_TASK_DIR / "source.csv") as conn:
        df = conn.fetch_by_keys(
            query_template="SELECT * FROM dbo.Employee_Tasks WHERE (:keys)",
            key_columns=["Employee_ID", "Task_ID"],
            key_values=[("E001", "T1"), ("E001", "T2"), ("E003", "T9")],
            key_batch_size=50000,
        )
    # (E003, T9) doesn't exist — only the two E001 rows should match.
    assert len(df) == 2
    assert set(df["Task_ID"]) == {"T1", "T2"}
