import pandas as pd

from dashboard.detail_data import filter_options, filter_rows, paginate, sort_rows

COLUMNS = [
    "Source DB Key",
    "Source Table",
    "Source Column",
    "Source Value",
    "Target DB Key",
    "Target Table",
    "Target Column",
    "Target Value",
    "Remarks",
]


def _df():
    return pd.DataFrame(
        [
            [
                "E001",
                "dbo.Employees",
                "Email",
                "a@x.com",
                "E001",
                "dbo.Target",
                "EMAIL_ADDR",
                "a@y.com",
                "VALUE MISMATCH",
            ],
            ["E002", "dbo.Employees", "", "E002", "", "dbo.Target", "", "", "MISSING DATA"],
            ["", "dbo.Employees", "", "", "E003", "dbo.Target", "", "E003", "MISSING DATA"],
            ["E004", "dbo.Employees", "", "E004", "E004", "dbo.Target", "", "E004", "DUPLICATE KEY"],
        ],
        columns=COLUMNS,
    )


def test_filter_by_record_key_matches_either_side():
    result = filter_rows(_df(), record_key="e003")
    assert list(result["Target DB Key"]) == ["E003"]

    result2 = filter_rows(_df(), record_key="e001")
    assert list(result2["Source DB Key"]) == ["E001"]


def test_filter_by_column_checks_both_source_and_target():
    result = filter_rows(_df(), column="email_addr")
    assert list(result["Source DB Key"]) == ["E001"]


def test_filter_by_remarks():
    result = filter_rows(_df(), remarks="DUPLICATE KEY")
    assert list(result["Source DB Key"]) == ["E004"]


def test_filter_by_search_scans_every_column():
    result = filter_rows(_df(), search="a@y.com")
    assert list(result["Source DB Key"]) == ["E001"]


def test_sort_rows_desc():
    result = sort_rows(_df(), "Source DB Key", "desc")
    assert list(result["Source DB Key"]) == ["E004", "E002", "E001", ""]


def test_sort_rows_unknown_column_is_noop():
    result = sort_rows(_df(), "Nonexistent", "asc")
    assert list(result["Source DB Key"]) == ["E001", "E002", "", "E004"]


def test_paginate():
    page_df, total = paginate(_df(), page=2, page_size=2)
    assert total == 4
    assert list(page_df["Target Column"]) == ["", ""]


def test_filter_options_excludes_blanks():
    df = _df()
    options = filter_options(df)
    assert options["remarks"] == ["DUPLICATE KEY", "MISSING DATA", "VALUE MISMATCH"]
