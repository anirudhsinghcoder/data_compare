from __future__ import annotations

import io
from pathlib import Path

from fastapi import APIRouter, HTTPException, Query, Request
from fastapi.responses import HTMLResponse, StreamingResponse
from fastapi.templating import Jinja2Templates

from .. import data, detail_data

BASE_DIR = Path(__file__).resolve().parent.parent
templates = Jinja2Templates(directory=BASE_DIR / "templates")

router = APIRouter()


def _load_filtered_sorted(
    comparison_id: str,
    report_id: str,
    *,
    remarks: str | None,
    record_key: str | None,
    column: str | None,
    search: str | None,
    sort_by: str | None,
    sort_dir: str | None,
):
    report = data.get_report(comparison_id, report_id)
    if report is None:
        raise HTTPException(status_code=404, detail="Report not found")
    df = detail_data.load_detail_dataframe(report)
    options = detail_data.filter_options(df)
    filtered = detail_data.filter_rows(
        df, remarks=remarks, record_key=record_key, column=column, search=search
    )
    sorted_df = detail_data.sort_rows(filtered, sort_by, sort_dir)
    return report, sorted_df, options


@router.get("/detail/{comparison_id}/{report_id}", response_class=HTMLResponse)
def detail_view(request: Request, comparison_id: str, report_id: str) -> HTMLResponse:
    comparisons = data.list_comparisons()
    if comparison_id not in comparisons:
        raise HTTPException(status_code=404, detail=f"Unknown comparison_id '{comparison_id}'")
    report, sorted_df, options = _load_filtered_sorted(
        comparison_id,
        report_id,
        remarks=None,
        record_key=None,
        column=None,
        search=None,
        sort_by=None,
        sort_dir=None,
    )
    page_df, total = detail_data.paginate(sorted_df, page=1, page_size=detail_data.DEFAULT_PAGE_SIZE)

    initial_payload = {
        "rows": detail_data.rows_to_records(page_df),
        "total": total,
        "page": 1,
        "page_size": detail_data.DEFAULT_PAGE_SIZE,
        "columns": list(sorted_df.columns) if len(sorted_df.columns) else [],
    }
    context = {
        "comparison_id": comparison_id,
        "comparison_name": comparisons[comparison_id].display_name,
        "report_id": report_id,
        "run_timestamp": report.run_timestamp.strftime("%Y-%m-%d %H:%M:%S"),
        "download_url": f"/download/{comparison_id}/{report_id}",
        "download_update_url": f"/download/{comparison_id}/{report_id}/update",
        "dashboard_url": f"/dashboard/{comparison_id}?report={report_id}",
        "filter_options": options,
        "initial_payload": initial_payload,
    }
    return templates.TemplateResponse(request, "detail.html", context)


@router.get("/api/detail/{comparison_id}/{report_id}")
def detail_rows(
    comparison_id: str,
    report_id: str,
    page: int = Query(1, ge=1),
    page_size: int = Query(detail_data.DEFAULT_PAGE_SIZE, ge=1, le=detail_data.MAX_PAGE_SIZE),
    sort_by: str | None = None,
    sort_dir: str | None = None,
    remarks: str | None = None,
    record_key: str | None = None,
    column: str | None = None,
    search: str | None = None,
) -> dict:
    _report, sorted_df, options = _load_filtered_sorted(
        comparison_id,
        report_id,
        remarks=remarks,
        record_key=record_key,
        column=column,
        search=search,
        sort_by=sort_by,
        sort_dir=sort_dir,
    )
    page_df, total = detail_data.paginate(sorted_df, page=page, page_size=page_size)
    return {
        "rows": detail_data.rows_to_records(page_df),
        "total": total,
        "page": page,
        "page_size": page_size,
        "filter_options": options,
    }


@router.get("/api/detail/{comparison_id}/{report_id}/export")
def export_detail_rows(
    comparison_id: str,
    report_id: str,
    format: str = Query("csv", pattern="^(csv|xlsx)$"),
    sort_by: str | None = None,
    sort_dir: str | None = None,
    remarks: str | None = None,
    record_key: str | None = None,
    column: str | None = None,
    search: str | None = None,
) -> StreamingResponse:
    _report, sorted_df, _options = _load_filtered_sorted(
        comparison_id,
        report_id,
        remarks=remarks,
        record_key=record_key,
        column=column,
        search=search,
        sort_by=sort_by,
        sort_dir=sort_dir,
    )

    filename = f"{report_id}_filtered.{format}"
    if format == "xlsx":
        buffer = io.BytesIO()
        sorted_df.to_excel(buffer, index=False, sheet_name="Filtered Mismatches")
        buffer.seek(0)
        media_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    else:
        buffer = io.BytesIO(sorted_df.to_csv(index=False).encode("utf-8"))
        media_type = "text/csv"

    return StreamingResponse(
        buffer,
        media_type=media_type,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )
