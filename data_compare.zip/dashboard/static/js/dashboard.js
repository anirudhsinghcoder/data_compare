(function () {
  var currentPayload = window.__INITIAL_PAYLOAD__ || null;
  var comparisonSelect = document.getElementById("comparison-select");
  var reportSelect = document.getElementById("report-select");
  var downloadLink = document.getElementById("download-link");
  var downloadUpdateLink = document.getElementById("download-update-link");
  var detailLink = document.getElementById("detail-link");
  var runMeta = document.getElementById("run-meta");
  var kpiGrid = document.getElementById("kpi-grid");

  function escapeHtml(value) {
    var div = document.createElement("div");
    div.textContent = value;
    return div.innerHTML;
  }

  function updateKpis(kpis) {
    if (!kpiGrid || !kpis) return;
    kpiGrid.innerHTML = kpis
      .map(function (card) {
        return (
          '<div class="kpi-card"><div class="kpi-label">' +
          escapeHtml(card.label) +
          '</div><div class="kpi-value">' +
          escapeHtml(String(card.value)) +
          "</div></div>"
        );
      })
      .join("");
  }

  function applyPayload(payload) {
    currentPayload = payload;
    if (!payload) return;
    if (downloadLink) {
      downloadLink.href = payload.download_url;
      downloadLink.removeAttribute("aria-disabled");
    }
    if (downloadUpdateLink) {
      downloadUpdateLink.href = payload.download_update_url;
      downloadUpdateLink.removeAttribute("aria-disabled");
    }
    if (detailLink) {
      detailLink.href = payload.detail_url;
      detailLink.removeAttribute("aria-disabled");
    }
    if (runMeta) {
      runMeta.textContent = "Run at " + payload.run_timestamp;
    }
    updateKpis(payload.kpis);
    if (window.DashboardCharts) window.DashboardCharts.render(payload);
  }

  if (comparisonSelect) {
    comparisonSelect.addEventListener("change", function () {
      window.location.href = "/dashboard/" + encodeURIComponent(comparisonSelect.value);
    });
  }

  if (reportSelect) {
    reportSelect.addEventListener("change", function () {
      var comparisonId = window.__COMPARISON_ID__;
      var reportId = reportSelect.value;
      fetch("/api/reports/" + encodeURIComponent(comparisonId) + "/" + encodeURIComponent(reportId))
        .then(function (res) {
          if (!res.ok) throw new Error("Request failed");
          return res.json();
        })
        .then(function (payload) {
          applyPayload(payload);
          var url = new URL(window.location.href);
          url.searchParams.set("report", reportId);
          window.history.replaceState({}, "", url);
        })
        .catch(function () {
          /* leave the current view in place on error */
        });
    });
  }

  if (currentPayload) {
    applyPayload(currentPayload);
  }

  window.addEventListener("theme-changed", function () {
    if (currentPayload && window.DashboardCharts) {
      window.DashboardCharts.render(currentPayload);
    }
  });
})();
