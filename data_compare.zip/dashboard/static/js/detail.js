(function () {
  var comparisonId = window.__COMPARISON_ID__;
  var reportId = window.__REPORT_ID__;
  var initial = window.__DETAIL_INITIAL__ || { rows: [], total: 0, page: 1, page_size: 25, columns: [] };

  var columns = initial.columns.length
    ? initial.columns
    : ["Source DB Key", "Source Table", "Source Column", "Source Value", "Target DB Key", "Target Table", "Target Column", "Target Value", "Remarks"];

  var state = {
    page: initial.page || 1,
    pageSize: initial.page_size || 25,
    sortBy: null,
    sortDir: "asc",
    remarks: "",
    recordKey: "",
    column: "",
    search: "",
  };

  var REMARKS_BADGE_CLASS = {
    "VALUE MISMATCH": "badge-critical",
    "MISSING DATA": "badge-serious",
    "DUPLICATE KEY": "badge-warning",
  };

  var tableHead = document.getElementById("detail-table-head");
  var tableBody = document.getElementById("detail-table-body");
  var resultCount = document.getElementById("result-count");
  var pageIndicator = document.getElementById("page-indicator");
  var pagePrev = document.getElementById("page-prev");
  var pageNext = document.getElementById("page-next");
  var pageSizeSelect = document.getElementById("page-size-select");

  function escapeHtml(value) {
    var div = document.createElement("div");
    div.textContent = value == null ? "" : String(value);
    return div.innerHTML;
  }

  function renderHead() {
    tableHead.innerHTML = columns
      .map(function (col) {
        var arrow = state.sortBy === col ? (state.sortDir === "desc" ? " ↓" : " ↑") : "";
        return '<th data-col="' + escapeHtml(col) + '">' + escapeHtml(col) + arrow + "</th>";
      })
      .join("");
    Array.prototype.forEach.call(tableHead.querySelectorAll("th"), function (th) {
      th.addEventListener("click", function () {
        var col = th.getAttribute("data-col");
        if (state.sortBy === col) {
          state.sortDir = state.sortDir === "asc" ? "desc" : "asc";
        } else {
          state.sortBy = col;
          state.sortDir = "asc";
        }
        state.page = 1;
        load();
      });
    });
  }

  function renderRows(rows) {
    if (!rows.length) {
      tableBody.innerHTML = '<tr><td class="muted" colspan="' + columns.length + '">No rows match these filters.</td></tr>';
      return;
    }
    tableBody.innerHTML = rows
      .map(function (row) {
        return (
          "<tr>" +
          columns
            .map(function (col) {
              var value = row[col];
              if (col === "Remarks" && value) {
                var cls = REMARKS_BADGE_CLASS[value] || "";
                return '<td><span class="badge ' + cls + '">' + escapeHtml(value) + "</span></td>";
              }
              return "<td>" + escapeHtml(value) + "</td>";
            })
            .join("") +
          "</tr>"
        );
      })
      .join("");
  }

  function updatePagination(total) {
    var totalPages = Math.max(1, Math.ceil(total / state.pageSize));
    if (state.page > totalPages) state.page = totalPages;
    resultCount.textContent = total.toLocaleString() + (total === 1 ? " row" : " rows");
    pageIndicator.textContent = "Page " + state.page + " of " + totalPages;
    pagePrev.disabled = state.page <= 1;
    pageNext.disabled = state.page >= totalPages;
  }

  function buildQuery(extra) {
    var params = new URLSearchParams();
    if (state.sortBy) params.set("sort_by", state.sortBy);
    if (state.sortBy) params.set("sort_dir", state.sortDir);
    if (state.remarks) params.set("remarks", state.remarks);
    if (state.recordKey) params.set("record_key", state.recordKey);
    if (state.column) params.set("column", state.column);
    if (state.search) params.set("search", state.search);
    if (extra) {
      Object.keys(extra).forEach(function (key) {
        params.set(key, extra[key]);
      });
    }
    return params.toString();
  }

  function load() {
    var query = buildQuery({ page: state.page, page_size: state.pageSize });
    fetch("/api/detail/" + encodeURIComponent(comparisonId) + "/" + encodeURIComponent(reportId) + "?" + query)
      .then(function (res) {
        if (!res.ok) throw new Error("Request failed");
        return res.json();
      })
      .then(function (payload) {
        renderHead();
        renderRows(payload.rows);
        updatePagination(payload.total);
      })
      .catch(function () {
        tableBody.innerHTML = '<tr><td class="muted" colspan="' + columns.length + '">Failed to load rows.</td></tr>';
      });
  }

  function debounce(fn, delay) {
    var timer = null;
    return function () {
      clearTimeout(timer);
      var args = arguments;
      timer = setTimeout(function () {
        fn.apply(null, args);
      }, delay);
    };
  }

  function onFilterChange() {
    state.page = 1;
    load();
  }
  var onFilterChangeDebounced = debounce(onFilterChange, 300);

  document.getElementById("filter-remarks").addEventListener("change", function (e) {
    state.remarks = e.target.value;
    onFilterChange();
  });
  document.getElementById("filter-record-key").addEventListener("input", function (e) {
    state.recordKey = e.target.value;
    onFilterChangeDebounced();
  });
  document.getElementById("filter-column").addEventListener("input", function (e) {
    state.column = e.target.value;
    onFilterChangeDebounced();
  });
  document.getElementById("filter-search").addEventListener("input", function (e) {
    state.search = e.target.value;
    onFilterChangeDebounced();
  });
  document.getElementById("clear-filters").addEventListener("click", function () {
    state.remarks = state.recordKey = state.column = state.search = "";
    document.getElementById("filter-remarks").value = "";
    document.getElementById("filter-record-key").value = "";
    document.getElementById("filter-column").value = "";
    document.getElementById("filter-search").value = "";
    onFilterChange();
  });

  pagePrev.addEventListener("click", function () {
    if (state.page > 1) {
      state.page -= 1;
      load();
    }
  });
  pageNext.addEventListener("click", function () {
    state.page += 1;
    load();
  });
  pageSizeSelect.addEventListener("change", function (e) {
    state.pageSize = parseInt(e.target.value, 10) || 25;
    state.page = 1;
    load();
  });

  document.getElementById("export-csv").addEventListener("click", function () {
    var query = buildQuery({ format: "csv" });
    window.location.href = "/api/detail/" + encodeURIComponent(comparisonId) + "/" + encodeURIComponent(reportId) + "/export?" + query;
  });
  document.getElementById("export-xlsx").addEventListener("click", function () {
    var query = buildQuery({ format: "xlsx" });
    window.location.href = "/api/detail/" + encodeURIComponent(comparisonId) + "/" + encodeURIComponent(reportId) + "/export?" + query;
  });

  renderHead();
  renderRows(initial.rows);
  updatePagination(initial.total);
  pageSizeSelect.value = String(state.pageSize);
})();
