"""Loads, filters, sorts and paginates one report's mismatch-detail rows.

Reads the `_details.csv` sidecar written by `comparator.report.build_report`
(the same rows as the Excel "Mismatch Details" sheet) — never the source or
target database, and not the .xlsx itself (the CSV is faster to filter and
paginate at the row counts this tool is sized for).
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from comparator.compare import MISMATCH_COLUMNS

from .data import ReportSummary

DEFAULT_PAGE_SIZE = 25
MAX_PAGE_SIZE = 500


def details_csv_path(report: ReportSummary) -> Path | None:
    filename = report.metadata.get("details_csv_file")
    if not filename:
        return None
    return report.json_path.parent / filename


def load_detail_dataframe(report: ReportSummary) -> pd.DataFrame:
    path = details_csv_path(report)
    if path is None or not path.exists():
        return pd.DataFrame(columns=MISMATCH_COLUMNS)
    return pd.read_csv(path, dtype=str, keep_default_na=False)


def filter_options(df: pd.DataFrame) -> dict[str, list[str]]:
    def distinct(col: str) -> list[str]:
        if col not in df.columns:
            return []
        return sorted(v for v in df[col].unique().tolist() if v)

    return {"remarks": distinct("Remarks")}


def filter_rows(
    df: pd.DataFrame,
    *,
    remarks: str | None = None,
    record_key: str | None = None,
    column: str | None = None,
    search: str | None = None,
) -> pd.DataFrame:
    filtered = df
    if remarks:
        filtered = filtered[filtered["Remarks"] == remarks]
    if record_key:
        needle = record_key.lower()
        filtered = filtered[
            filtered["Source DB Key"].str.lower().str.contains(needle, na=False, regex=False)
            | filtered["Target DB Key"].str.lower().str.contains(needle, na=False, regex=False)
        ]
    if column:
        needle = column.lower()
        filtered = filtered[
            filtered["Source Column"].str.lower().str.contains(needle, na=False, regex=False)
            | filtered["Target Column"].str.lower().str.contains(needle, na=False, regex=False)
        ]
    if search:
        needle = search.lower()
        mask = pd.Series(False, index=filtered.index)
        for col in filtered.columns:
            mask = mask | filtered[col].astype(str).str.lower().str.contains(needle, na=False, regex=False)
        filtered = filtered[mask]
    return filtered


def sort_rows(df: pd.DataFrame, sort_by: str | None, sort_dir: str | None) -> pd.DataFrame:
    if not sort_by or sort_by not in df.columns:
        return df
    return df.sort_values(by=sort_by, ascending=(sort_dir != "desc"), kind="stable")


def paginate(df: pd.DataFrame, page: int, page_size: int) -> tuple[pd.DataFrame, int]:
    page = max(page, 1)
    page_size = max(1, min(page_size, MAX_PAGE_SIZE))
    total = len(df)
    start = (page - 1) * page_size
    return df.iloc[start : start + page_size], total


def rows_to_records(df: pd.DataFrame) -> list[dict]:
    return df.to_dict(orient="records")
