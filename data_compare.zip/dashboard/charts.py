"""Transforms report run-metadata into the KPI cards and Chart.js-ready
structures the dashboard template and the /api/reports endpoint both use.
"""

from __future__ import annotations

from .data import ReportSummary


def kpi_cards(report: ReportSummary) -> list[dict]:
    meta = report.metadata
    summary = meta["summary"]

    return [
        {"label": "Input key count", "value": f"{meta['input_key_count']:,}"},
        {"label": "Match %", "value": f"{summary['match_percentage']:.1f}%"},
        {"label": "Mismatch rows", "value": f"{meta['mismatch_row_count']:,}"},
        {"label": "Records to update", "value": f"{meta.get('update_row_count', 0):,}"},
        {
            "label": "Missing records",
            "value": f"{summary['missing_in_target'] + summary['missing_in_source']:,}",
        },
        {"label": "Duplicate keys", "value": f"{summary['duplicate_keys']:,}"},
        {"label": "Run duration", "value": f"{meta['duration_seconds']:.1f}s"},
    ]


def donut_data(report: ReportSummary) -> dict:
    summary = report.metadata["summary"]
    return {
        "labels": ["Matched", "Mismatched", "Missing", "Duplicate keys"],
        "values": [
            summary["matched"],
            summary["mismatched"],
            summary["missing_in_target"] + summary["missing_in_source"],
            summary["duplicate_keys"],
        ],
    }


def mismatch_by_column_data(report: ReportSummary) -> dict:
    counts = report.metadata["summary"].get("mismatch_counts_by_column", {})
    labels = sorted(counts)
    return {"labels": labels, "values": [counts[label] for label in labels]}


def source_vs_target_data(report: ReportSummary) -> dict:
    totals = report.metadata["totals"]
    return {
        "labels": ["Source DB", "Target DB"],
        "values": [totals.get("source_db", 0), totals.get("target_db", 0)],
    }


def match_percentage_trend(reports: list[ReportSummary]) -> dict:
    ordered = sorted(reports, key=lambda r: r.run_timestamp)
    return {
        "labels": [r.run_timestamp.strftime("%Y-%m-%d %H:%M") for r in ordered],
        "values": [r.metadata["summary"]["match_percentage"] for r in ordered],
    }


def report_payload(report: ReportSummary, all_reports: list[ReportSummary]) -> dict:
    """Everything the dashboard page needs for one selected report."""
    return {
        "report_id": report.report_id,
        "run_timestamp": report.run_timestamp.strftime("%Y-%m-%d %H:%M:%S"),
        "kpis": kpi_cards(report),
        "donut": donut_data(report),
        "mismatch_by_column": mismatch_by_column_data(report),
        "source_vs_target": source_vs_target_data(report),
        "trend": match_percentage_trend(all_reports),
        "download_url": f"/download/{report.comparison_id}/{report.report_id}",
        "download_update_url": f"/download/{report.comparison_id}/{report.report_id}/update",
        "detail_url": f"/detail/{report.comparison_id}/{report.report_id}",
    }
