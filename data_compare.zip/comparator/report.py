"""Excel report writer (openpyxl: Summary + Mismatch Details sheets), a
run-metadata JSON record the dashboard reads instead of re-parsing Excel, a
details CSV sidecar for the dashboard's Detail page, and a pipe-separated
"update" file listing, per mismatched record, the columns that need
updating in the target.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd
from openpyxl import Workbook
from openpyxl.formatting.rule import CellIsRule
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

from .compare import DUPLICATE_KEY, MISMATCH_COLUMNS, MISSING_DATA, VALUE_MISMATCH, ComparisonResult
from .config import ComparisonConfig

HEADER_FILL = PatternFill(start_color="FF1F4E78", end_color="FF1F4E78", fill_type="solid")
HEADER_FONT = Font(bold=True, color="FFFFFFFF")
LABEL_FONT = Font(bold=True)
TITLE_FONT = Font(bold=True, size=13)

MISMATCH_FILL = PatternFill(start_color="FFFFC7CE", end_color="FFFFC7CE", fill_type="solid")
MISSING_FILL = PatternFill(start_color="FFFFEB9C", end_color="FFFFEB9C", fill_type="solid")
DUPLICATE_FILL = PatternFill(start_color="FFFFD966", end_color="FFFFD966", fill_type="solid")

UPDATE_ACTION = "UPDATE"


@dataclass
class RunInfo:
    started_at: datetime
    duration_seconds: float
    input_key_count: int
    totals: dict[str, int]


def _style_header_row(ws: Worksheet, row: int, num_cols: int) -> None:
    for col in range(1, num_cols + 1):
        cell = ws.cell(row=row, column=col)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="center", vertical="center")


def _set_column_widths(ws: Worksheet, widths: list[int]) -> None:
    for i, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = width


def write_summary_sheet(
    ws: Worksheet, *, config: ComparisonConfig, run_info: RunInfo, result: ComparisonResult
) -> None:
    ws.title = "Summary"
    _set_column_widths(ws, [40, 20, 20, 20, 20, 20, 12])

    ws.append((config.display_name,))
    ws["A1"].font = TITLE_FONT
    ws.append(())

    summary = result.summary
    label_rows = [
        ("Comparison ID", config.comparison_id),
        ("Run Timestamp", run_info.started_at.strftime("%Y-%m-%d %H:%M:%S")),
        ("Duration (seconds)", round(run_info.duration_seconds, 2)),
        ("Input Key Count", run_info.input_key_count),
        ("Total Records — Source DB", run_info.totals.get("source_db", 0)),
        ("Total Records — Target DB", run_info.totals.get("target_db", 0)),
    ]
    for label, value in label_rows:
        ws.append((label, value))
        ws.cell(row=ws.max_row, column=1).font = LABEL_FONT

    ws.append(())
    ws.append(("Results",))
    ws.cell(row=ws.max_row, column=1).font = LABEL_FONT
    header_row = ws.max_row + 1
    ws.append(
        ("Matched", "Mismatched", "Missing In Target", "Missing In Source", "Duplicate Keys", "Match %")
    )
    _style_header_row(ws, header_row, 6)
    ws.append(
        (
            summary.matched,
            summary.mismatched,
            summary.missing_in_target,
            summary.missing_in_source,
            summary.duplicate_keys,
            summary.match_percentage,
        )
    )

    ws.append(())
    ws.append(("Mismatch Count Per Column",))
    ws.cell(row=ws.max_row, column=1).font = LABEL_FONT
    header_row_2 = ws.max_row + 1
    ws.append(("Target Column", "Mismatch Count"))
    _style_header_row(ws, header_row_2, 2)
    if summary.mismatch_counts_by_column:
        for column, count in sorted(summary.mismatch_counts_by_column.items()):
            ws.append((column, count))
    else:
        ws.append(("—", 0))

    ws.freeze_panes = "A2"


def write_detail_sheet(ws: Worksheet, result: ComparisonResult) -> None:
    ws.title = "Mismatch Details"
    ws.append(MISMATCH_COLUMNS)
    _style_header_row(ws, 1, len(MISMATCH_COLUMNS))
    _set_column_widths(ws, [18, 22, 20, 30, 18, 22, 20, 30, 16])

    for row in result.rows:
        ws.append(tuple(row.get(col) for col in MISMATCH_COLUMNS))

    last_row = ws.max_row
    if last_row > 1:
        remarks_col_letter = get_column_letter(len(MISMATCH_COLUMNS))
        full_range = f"{remarks_col_letter}2:{remarks_col_letter}{last_row}"
        ws.conditional_formatting.add(
            full_range, CellIsRule(operator="equal", formula=[f'"{VALUE_MISMATCH}"'], fill=MISMATCH_FILL)
        )
        ws.conditional_formatting.add(
            full_range, CellIsRule(operator="equal", formula=[f'"{MISSING_DATA}"'], fill=MISSING_FILL)
        )
        ws.conditional_formatting.add(
            full_range, CellIsRule(operator="equal", formula=[f'"{DUPLICATE_KEY}"'], fill=DUPLICATE_FILL)
        )

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(MISMATCH_COLUMNS))}{max(last_row, 1)}"


def build_update_pipe_rows(
    result: ComparisonResult, config: ComparisonConfig
) -> tuple[list[str], list[dict]]:
    """Group VALUE MISMATCH rows by record, one output row per record listing
    every column that differed. Pipe-delimited output, meant to drive a
    downstream UPDATE of just the mismatched columns in the target."""
    source_key_columns = config.keys.source
    target_key_columns = config.keys.target
    columns = [f"Source_Column_Key_{i + 1}" for i in range(len(source_key_columns))]
    columns += [f"Target_Column_Key_{i + 1}" for i in range(len(target_key_columns))]
    columns += ["Mismatched_Columns", "Action"]

    grouped: dict[tuple, dict[str, Any]] = {}
    for row in result.rows:
        if row["Remarks"] != VALUE_MISMATCH:
            continue
        key = (row["_source_key_values"], row["_target_key_values"])
        entry = grouped.setdefault(
            key,
            {
                "source_key_values": row["_source_key_values"],
                "target_key_values": row["_target_key_values"],
                "columns": [],
            },
        )
        if row["Target Column"] not in entry["columns"]:
            entry["columns"].append(row["Target Column"])

    pipe_rows = []
    for entry in grouped.values():
        source_vals = entry["source_key_values"] or ()
        target_vals = entry["target_key_values"] or ()
        record: dict[str, Any] = {}
        for i in range(len(source_key_columns)):
            record[f"Source_Column_Key_{i + 1}"] = source_vals[i] if i < len(source_vals) else ""
        for i in range(len(target_key_columns)):
            record[f"Target_Column_Key_{i + 1}"] = target_vals[i] if i < len(target_vals) else ""
        record["Mismatched_Columns"] = ",".join(entry["columns"])
        record["Action"] = UPDATE_ACTION
        pipe_rows.append(record)
    return columns, pipe_rows


def write_update_pipe_file(columns: list[str], pipe_rows: list[dict], path: Path) -> None:
    pd.DataFrame(pipe_rows, columns=columns).to_csv(path, sep="|", index=False)


def build_report(
    config: ComparisonConfig,
    result: ComparisonResult,
    run_info: RunInfo,
    reports_dir: Path,
) -> tuple[Path, Path, Path, Path]:
    """Writes the .xlsx report, a sibling .json run-metadata file, a sibling
    _details.csv (dashboard Detail page), and a sibling _update.txt
    pipe-separated file (mismatched records only, one row per record).
    Returns (xlsx_path, json_path, details_csv_path, update_pipe_path)."""
    timestamp = run_info.started_at.strftime("%Y%m%d_%H%M%S")
    out_dir = reports_dir / config.comparison_id
    out_dir.mkdir(parents=True, exist_ok=True)
    base_name = f"{config.comparison_id}_{timestamp}"
    xlsx_path = out_dir / f"{base_name}.xlsx"
    json_path = out_dir / f"{base_name}.json"
    details_csv_path = out_dir / f"{base_name}_details.csv"
    update_pipe_path = out_dir / f"{base_name}_update.txt"

    wb = Workbook()
    write_summary_sheet(wb.active, config=config, run_info=run_info, result=result)
    write_detail_sheet(wb.create_sheet("Mismatch Details"), result)
    wb.save(xlsx_path)

    result.mismatch_dataframe().to_csv(details_csv_path, index=False)

    pipe_columns, pipe_rows = build_update_pipe_rows(result, config)
    write_update_pipe_file(pipe_columns, pipe_rows, update_pipe_path)

    summary = result.summary
    metadata: dict[str, Any] = {
        "comparison_id": config.comparison_id,
        "display_name": config.display_name,
        "run_timestamp": run_info.started_at.isoformat(),
        "duration_seconds": round(run_info.duration_seconds, 2),
        "input_key_count": run_info.input_key_count,
        "totals": run_info.totals,
        "mismatch_row_count": len(result.rows),
        "update_row_count": len(pipe_rows),
        "excel_file": xlsx_path.name,
        "details_csv_file": details_csv_path.name,
        "update_pipe_file": update_pipe_path.name,
        "summary": {
            "total_source_db": summary.total_source_db,
            "total_target_db": summary.total_target_db,
            "matched": summary.matched,
            "mismatched": summary.mismatched,
            "missing_in_target": summary.missing_in_target,
            "missing_in_source": summary.missing_in_source,
            "duplicate_keys": summary.duplicate_keys,
            "mismatch_counts_by_column": summary.mismatch_counts_by_column,
            "match_percentage": summary.match_percentage,
        },
    }
    json_path.write_text(json.dumps(metadata, indent=2, default=str), encoding="utf-8")
    return xlsx_path, json_path, details_csv_path, update_pipe_path
