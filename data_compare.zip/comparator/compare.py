"""Comparison engine: matches source and target records on (possibly
composite) keys, and reports value mismatches, missing records and
duplicate keys. Vectorized with pandas merges — no per-row Python loops.

Single source, single target (no SOURCE_SYSTEM routing — that only existed
when there were two source systems feeding one target).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import pandas as pd

from .config import ColumnMapping, ComparisonConfig, KeyNormalizationConfig, OptionsConfig
from .normalize import build_key_series, columns_equal

VALUE_MISMATCH = "VALUE MISMATCH"
MISSING_DATA = "MISSING DATA"
DUPLICATE_KEY = "DUPLICATE KEY"

MISMATCH_COLUMNS = [
    "Source DB Key",
    "Source Table",
    "Source Column",
    "Source Value",
    "Target DB Key",
    "Target Table",
    "Target Column",
    "Target Value",
    "Remarks",
]


def join_key_values(values: tuple | None) -> str | None:
    if values is None:
        return None
    return "|".join("" if v is None else str(v) for v in values)


@dataclass
class ComparisonSummary:
    total_source_db: int = 0
    total_target_db: int = 0
    matched: int = 0
    mismatched: int = 0
    missing_in_target: int = 0
    missing_in_source: int = 0
    duplicate_keys: int = 0
    mismatch_counts_by_column: dict[str, int] = field(default_factory=dict)

    @property
    def total_compared(self) -> int:
        return self.matched + self.mismatched + self.missing_in_target + self.missing_in_source

    @property
    def match_percentage(self) -> float:
        if self.total_compared == 0:
            return 0.0
        return round(self.matched / self.total_compared * 100, 2)


@dataclass
class ComparisonResult:
    rows: list[dict[str, Any]]
    summary: ComparisonSummary

    def mismatch_dataframe(self) -> pd.DataFrame:
        return pd.DataFrame(self.rows, columns=MISMATCH_COLUMNS)


def _find_duplicate_keys(key_series: pd.Series) -> set[str]:
    dup_mask = key_series.duplicated(keep=False)
    return set(key_series[dup_mask].unique())


def run_comparison(
    *,
    source_df: pd.DataFrame,
    target_df: pd.DataFrame,
    config: ComparisonConfig,
) -> ComparisonResult:
    key_columns_source = config.keys.source
    key_columns_target = config.keys.target
    key_normalization: KeyNormalizationConfig = config.key_normalization
    options: OptionsConfig = config.options
    source_tz = config.timezone.source_tz
    source_table_name = config.tables.source.name
    target_table_name = config.tables.target.name
    column_mappings: list[ColumnMapping] = config.column_mappings

    summary = ComparisonSummary(total_source_db=len(source_df), total_target_db=len(target_df))
    rows: list[dict[str, Any]] = []

    src_key = build_key_series(source_df, key_columns_source, key_normalization)
    tgt_key = build_key_series(target_df, key_columns_target, key_normalization)

    duplicate_keys = _find_duplicate_keys(src_key) | _find_duplicate_keys(tgt_key)
    for dup_key in duplicate_keys:
        src_row = source_df[src_key == dup_key]
        tgt_row = target_df[tgt_key == dup_key]
        source_key_values = (
            tuple(src_row.iloc[0][c] for c in key_columns_source) if len(src_row) > 0 else None
        )
        target_key_values = (
            tuple(tgt_row.iloc[0][c] for c in key_columns_target) if len(tgt_row) > 0 else None
        )
        rows.append(
            {
                "Source DB Key": join_key_values(source_key_values),
                "Source Table": source_table_name,
                "Source Column": None,
                "Source Value": None,
                "Target DB Key": join_key_values(target_key_values),
                "Target Table": target_table_name,
                "Target Column": None,
                "Target Value": None,
                "Remarks": DUPLICATE_KEY,
                "_source_key_values": source_key_values,
                "_target_key_values": target_key_values,
            }
        )
    summary.duplicate_keys = len(duplicate_keys)

    not_dup_src = ~src_key.isin(duplicate_keys)
    not_dup_tgt = ~tgt_key.isin(duplicate_keys)
    source_clean = source_df[not_dup_src].reset_index(drop=True)
    target_clean = target_df[not_dup_tgt].reset_index(drop=True)
    src_key_clean = src_key[not_dup_src].reset_index(drop=True)
    tgt_key_clean = tgt_key[not_dup_tgt].reset_index(drop=True)

    src_lookup = pd.DataFrame({"_key": src_key_clean, "_src_idx": source_clean.index})
    tgt_lookup = pd.DataFrame({"_key": tgt_key_clean, "_tgt_idx": target_clean.index})
    merged = src_lookup.merge(tgt_lookup, on="_key", how="outer")

    matched_mask = merged["_src_idx"].notna() & merged["_tgt_idx"].notna()
    missing_in_target_mask = merged["_src_idx"].notna() & merged["_tgt_idx"].isna()
    missing_in_source_mask = merged["_src_idx"].isna() & merged["_tgt_idx"].notna()

    missing_in_target = merged[missing_in_target_mask]
    for src_idx in missing_in_target["_src_idx"].astype(int):
        source_key_values = tuple(source_clean.iloc[src_idx][c] for c in key_columns_source)
        rows.append(
            {
                "Source DB Key": join_key_values(source_key_values),
                "Source Table": source_table_name,
                "Source Column": None,
                "Source Value": None,
                "Target DB Key": None,
                "Target Table": target_table_name,
                "Target Column": None,
                "Target Value": None,
                "Remarks": MISSING_DATA,
                "_source_key_values": source_key_values,
                "_target_key_values": None,
            }
        )
    summary.missing_in_target = len(missing_in_target)

    missing_in_source = merged[missing_in_source_mask]
    for tgt_idx in missing_in_source["_tgt_idx"].astype(int):
        target_key_values = tuple(target_clean.iloc[tgt_idx][c] for c in key_columns_target)
        rows.append(
            {
                "Source DB Key": None,
                "Source Table": source_table_name,
                "Source Column": None,
                "Source Value": None,
                "Target DB Key": join_key_values(target_key_values),
                "Target Table": target_table_name,
                "Target Column": None,
                "Target Value": None,
                "Remarks": MISSING_DATA,
                "_source_key_values": None,
                "_target_key_values": target_key_values,
            }
        )
    summary.missing_in_source = len(missing_in_source)

    matched = merged[matched_mask]
    if len(matched) > 0:
        matched_src_idx = matched["_src_idx"].astype(int).to_numpy()
        matched_tgt_idx = matched["_tgt_idx"].astype(int).to_numpy()
        matched_src_df = source_clean.iloc[matched_src_idx].reset_index(drop=True)
        matched_tgt_df = target_clean.iloc[matched_tgt_idx].reset_index(drop=True)

        mismatched_keys: set[int] = set()
        for mapping in column_mappings:
            equal = columns_equal(
                matched_src_df[mapping.source_column],
                matched_tgt_df[mapping.target_column],
                mapping,
                source_tz=source_tz,
                null_empty_equivalent=options.null_empty_equivalent,
                default_numeric_tolerance=options.numeric_tolerance,
            )
            mismatch_positions = (~equal).to_numpy().nonzero()[0]
            if len(mismatch_positions) == 0:
                continue
            summary.mismatch_counts_by_column[mapping.target_column] = summary.mismatch_counts_by_column.get(
                mapping.target_column, 0
            ) + len(mismatch_positions)
            for pos in mismatch_positions:
                mismatched_keys.add(pos)
                source_key_values = tuple(matched_src_df.iloc[pos][c] for c in key_columns_source)
                target_key_values = tuple(matched_tgt_df.iloc[pos][c] for c in key_columns_target)
                rows.append(
                    {
                        "Source DB Key": join_key_values(source_key_values),
                        "Source Table": source_table_name,
                        "Source Column": mapping.source_column,
                        "Source Value": matched_src_df.iloc[pos][mapping.source_column],
                        "Target DB Key": join_key_values(target_key_values),
                        "Target Table": target_table_name,
                        "Target Column": mapping.target_column,
                        "Target Value": matched_tgt_df.iloc[pos][mapping.target_column],
                        "Remarks": VALUE_MISMATCH,
                        "_source_key_values": source_key_values,
                        "_target_key_values": target_key_values,
                    }
                )
        summary.mismatched = len(mismatched_keys)
        summary.matched = len(matched) - len(mismatched_keys)
    else:
        summary.matched = 0

    return ComparisonResult(rows=rows, summary=summary)


__all__ = [
    "VALUE_MISMATCH",
    "MISSING_DATA",
    "DUPLICATE_KEY",
    "MISMATCH_COLUMNS",
    "ComparisonSummary",
    "ComparisonResult",
    "run_comparison",
    "join_key_values",
]
