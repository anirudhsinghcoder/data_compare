"""Value and key normalization so equivalent values compare as equal.

No business transformation happens here — only enough normalization to make
differing formats, timezones, and whitespace/case line up before comparison.
Everything here is vectorized pandas (no per-row Python loops), to stay
efficient at the documented volumes (tens of thousands to a few million rows).
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .config import ColumnMapping, ColumnType, KeyNormalizationConfig

UTC = "UTC"


# --------------------------------------------------------------------------- #
# Key normalization
# --------------------------------------------------------------------------- #


def normalize_key_column(series: pd.Series, cfg: KeyNormalizationConfig) -> pd.Series:
    """Normalize a single key column to a canonical string for matching."""
    s = series.astype("string")
    if cfg.trim:
        s = s.str.strip()
    if cfg.strip_leading_zeros:
        # Only strip leading zeros from values that are purely digits, so an
        # alphanumeric key like "A007" is left alone.
        all_digits = s.str.fullmatch(r"0*\d+")
        stripped = s.str.lstrip("0")
        stripped = stripped.mask(stripped == "", "0")
        s = s.where(~all_digits.fillna(False), stripped)
    if cfg.case_insensitive:
        s = s.str.casefold()
    return s


def build_key_series(df: pd.DataFrame, key_columns: list[str], cfg: KeyNormalizationConfig) -> pd.Series:
    """Join normalized key column(s) into one canonical string key per row,
    used for merging and duplicate detection. Works for single or composite
    keys identically."""
    normalized = [normalize_key_column(df[col], cfg) for col in key_columns]
    joined = normalized[0].astype("string")
    for col in normalized[1:]:
        joined = joined.str.cat(col.astype("string"), sep="\x1f")
    return joined


# --------------------------------------------------------------------------- #
# Value normalization
# --------------------------------------------------------------------------- #


def _is_blank_string(series: pd.Series) -> pd.Series:
    return series.astype("string").str.strip() == ""


def is_na_or_blank(series: pd.Series, *, null_empty_equivalent: bool) -> pd.Series:
    na = series.isna()
    if not null_empty_equivalent:
        return na
    is_string_like = series.dtype == object or str(series.dtype).startswith("string")
    if is_string_like:
        return na | _is_blank_string(series.where(~na, ""))
    return na


def normalize_string_series(series: pd.Series, *, trim: bool, case_insensitive: bool) -> pd.Series:
    s = series.astype("string")
    if trim:
        s = s.str.strip()
    if case_insensitive:
        s = s.str.casefold()
    return s


def normalize_number_series(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce")


def normalize_date_series(series: pd.Series) -> pd.Series:
    return pd.to_datetime(series, errors="coerce").dt.date


def normalize_datetime_series(series: pd.Series, *, assumed_tz: str) -> pd.Series:
    """Parse to datetime and convert to UTC. Naive timestamps are assumed to
    represent `assumed_tz` local time (e.g. 'America/Chicago' for source
    columns, 'UTC' for target columns which already store UTC)."""
    dt = pd.to_datetime(series, errors="coerce")
    if dt.dt.tz is None:
        dt = dt.dt.tz_localize(assumed_tz, ambiguous="NaT", nonexistent="NaT")
    return dt.dt.tz_convert(UTC)


def normalize_for_comparison(
    series: pd.Series,
    mapping: ColumnMapping,
    *,
    side_tz: str,
) -> pd.Series:
    """Normalize one column's values for equality comparison, per its
    configured type. `side_tz` is the timezone naive datetimes in this
    column should be assumed to be in ('America/Chicago' for a source
    column, 'UTC' for a target column)."""
    if mapping.type == ColumnType.STRING:
        return normalize_string_series(series, trim=mapping.trim, case_insensitive=mapping.case_insensitive)
    if mapping.type == ColumnType.NUMBER:
        return normalize_number_series(series)
    if mapping.type == ColumnType.DATE:
        return normalize_date_series(series)
    if mapping.type in (ColumnType.DATETIME, ColumnType.TIMESTAMP):
        return normalize_datetime_series(series, assumed_tz=side_tz)
    raise ValueError(f"Unsupported column type: {mapping.type}")


def columns_equal(
    source_values: pd.Series,
    target_values: pd.Series,
    mapping: ColumnMapping,
    *,
    source_tz: str,
    null_empty_equivalent: bool,
    default_numeric_tolerance: float,
) -> pd.Series:
    """Return a boolean Series, aligned to source_values.index, of whether
    each row's source/target value is equivalent under the configured
    normalization rules."""
    source_norm = normalize_for_comparison(source_values, mapping, side_tz=source_tz)
    target_norm = normalize_for_comparison(target_values, mapping, side_tz=UTC)

    source_na = is_na_or_blank(source_values, null_empty_equivalent=null_empty_equivalent)
    target_na = is_na_or_blank(target_values, null_empty_equivalent=null_empty_equivalent)
    both_na = source_na & target_na
    exactly_one_na = source_na ^ target_na

    if mapping.type == ColumnType.NUMBER:
        tolerance = (
            mapping.numeric_tolerance if mapping.numeric_tolerance is not None else default_numeric_tolerance
        )
        source_f = source_norm.astype(float).to_numpy()
        target_f = target_norm.astype(float).to_numpy()
        with np.errstate(invalid="ignore"):
            close = np.isclose(source_f, target_f, atol=tolerance, equal_nan=False)
        equal = pd.Series(close, index=source_values.index)
    else:
        equal = source_norm.eq(target_norm)

    equal = equal.fillna(False)
    equal = equal | both_na
    equal = equal & ~exactly_one_na
    return equal
