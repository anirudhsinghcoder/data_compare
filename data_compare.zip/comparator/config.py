"""Pydantic config models and YAML loaders for connections.yaml and comparisons/*.yaml."""

from __future__ import annotations

import os
import re
from enum import Enum
from pathlib import Path
from typing import Literal

import yaml
from pydantic import BaseModel, Field, ValidationError, field_validator, model_validator

IDENTIFIER_RE = re.compile(r"^[a-z][a-z0-9_]*$")


class ConfigError(Exception):
    """Raised for config file problems, with a message meant to be shown to the user."""


# --------------------------------------------------------------------------- #
# connections.yaml
# --------------------------------------------------------------------------- #


class ServicePrincipalConfig(BaseModel):
    """Azure AD app registration used to authenticate to Azure SQL
    (ActiveDirectoryServicePrincipal) and, when reused for Always Encrypted,
    to unwrap the column master key from Key Vault."""

    client_id_env: str
    client_secret_env: str
    tenant_id_env: str | None = None


class AlwaysEncryptedConfig(BaseModel):
    enabled: bool = False
    key_vault_url_env: str | None = None

    @model_validator(mode="after")
    def _require_fields_when_enabled(self) -> AlwaysEncryptedConfig:
        if self.enabled and not self.key_vault_url_env:
            raise ValueError("always_encrypted.enabled is true but key_vault_url_env is missing")
        return self


class AzureSqlConnectionConfig(BaseModel):
    type: Literal["azure_sql"] = "azure_sql"
    driver: str = "ODBC Driver 18 for SQL Server"
    server_env: str
    database_env: str
    service_principal: ServicePrincipalConfig
    encrypt: bool = True
    trust_server_certificate: bool = False
    # Always Encrypted's Key Vault access reuses this connection's own
    # service_principal (it needs get/unwrapKey on the column master key) —
    # there is no separate credential to configure.
    always_encrypted: AlwaysEncryptedConfig = Field(default_factory=AlwaysEncryptedConfig)


class ConnectionsConfig(BaseModel):
    source: AzureSqlConnectionConfig
    target: AzureSqlConnectionConfig


def resolve_env(var_name: str) -> str:
    """Read a required env var, raising a clear ConfigError (never logs the value)."""
    value = os.environ.get(var_name)
    if value is None or value == "":
        raise ConfigError(f"Required environment variable '{var_name}' is not set.")
    return value


# --------------------------------------------------------------------------- #
# comparisons/<id>.yaml
# --------------------------------------------------------------------------- #


class ColumnType(str, Enum):
    STRING = "string"
    NUMBER = "number"
    DATE = "date"
    DATETIME = "datetime"
    TIMESTAMP = "timestamp"


class InputExtractionConfig(BaseModel):
    """SELECT run against the source database to get the keys to compare."""

    query: str
    output_dir: str
    reuse_existing_by_default: bool = True


class TimezoneConfig(BaseModel):
    source_tz: str = "America/Chicago"


class KeysConfig(BaseModel):
    source: list[str] = Field(min_length=1)
    target: list[str] = Field(min_length=1)

    @model_validator(mode="after")
    def _same_arity(self) -> KeysConfig:
        if len(self.source) != len(self.target):
            raise ValueError(
                f"keys.source and keys.target must have the same number of columns "
                f"(got {len(self.source)}, {len(self.target)})"
            )
        return self


class KeyNormalizationConfig(BaseModel):
    trim: bool = True
    strip_leading_zeros: bool = False
    case_insensitive: bool = False


class TableQueryConfig(BaseModel):
    name: str
    query: str

    @field_validator("query")
    @classmethod
    def _must_reference_keys(cls, value: str) -> str:
        if ":keys" not in value:
            raise ValueError("query must contain the ':keys' placeholder")
        return value


class TablesConfig(BaseModel):
    source: TableQueryConfig
    target: TableQueryConfig


class ColumnMapping(BaseModel):
    source_column: str
    target_column: str
    type: ColumnType = ColumnType.STRING
    trim: bool = False
    case_insensitive: bool = False
    numeric_tolerance: float | None = None


class OptionsConfig(BaseModel):
    null_empty_equivalent: bool = True
    numeric_tolerance: float = 0.0001


class ProcessingConfig(BaseModel):
    key_batch_size: int = Field(default=50000, gt=0, le=200000)


class ComparisonConfig(BaseModel):
    comparison_id: str
    display_name: str
    input_extraction: InputExtractionConfig
    timezone: TimezoneConfig = Field(default_factory=TimezoneConfig)
    keys: KeysConfig
    key_normalization: KeyNormalizationConfig = Field(default_factory=KeyNormalizationConfig)
    tables: TablesConfig
    column_mappings: list[ColumnMapping] = Field(min_length=1)
    options: OptionsConfig = Field(default_factory=OptionsConfig)
    processing: ProcessingConfig = Field(default_factory=ProcessingConfig)

    @field_validator("comparison_id")
    @classmethod
    def _valid_identifier(cls, value: str) -> str:
        if not IDENTIFIER_RE.match(value):
            raise ValueError(
                f"comparison_id '{value}' must be lowercase, start with a letter, "
                "and contain only letters, digits and underscores"
            )
        return value


# --------------------------------------------------------------------------- #
# Loaders
# --------------------------------------------------------------------------- #


def _load_yaml(path: Path) -> dict:
    if not path.exists():
        raise ConfigError(f"Config file not found: {path}")
    with path.open("r", encoding="utf-8") as f:
        try:
            data = yaml.safe_load(f)
        except yaml.YAMLError as exc:
            raise ConfigError(f"Invalid YAML in {path}: {exc}") from exc
    if not isinstance(data, dict):
        raise ConfigError(f"{path} must contain a YAML mapping at the top level")
    return data


def _format_validation_error(path: Path, exc: ValidationError) -> str:
    lines = [f"Invalid config in {path}:"]
    for error in exc.errors():
        loc = ".".join(str(part) for part in error["loc"])
        lines.append(f"  - {loc}: {error['msg']}")
    return "\n".join(lines)


def load_connections(path: str | Path) -> ConnectionsConfig:
    path = Path(path)
    data = _load_yaml(path)
    try:
        return ConnectionsConfig.model_validate(data)
    except ValidationError as exc:
        raise ConfigError(_format_validation_error(path, exc)) from exc


def load_comparison_config(path: str | Path) -> ComparisonConfig:
    path = Path(path)
    data = _load_yaml(path)
    try:
        return ComparisonConfig.model_validate(data)
    except ValidationError as exc:
        raise ConfigError(_format_validation_error(path, exc)) from exc


def load_all_comparisons(comparisons_dir: str | Path) -> dict[str, ComparisonConfig]:
    comparisons_dir = Path(comparisons_dir)
    if not comparisons_dir.exists():
        raise ConfigError(f"Comparisons directory not found: {comparisons_dir}")

    configs: dict[str, ComparisonConfig] = {}
    for yaml_path in sorted(comparisons_dir.glob("*.yaml")):
        config = load_comparison_config(yaml_path)
        if config.comparison_id in configs:
            raise ConfigError(
                f"Duplicate comparison_id '{config.comparison_id}' in {yaml_path} "
                f"(already defined by another file)"
            )
        configs[config.comparison_id] = config
    return configs
