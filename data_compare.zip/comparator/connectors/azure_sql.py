"""Azure SQL connector (pyodbc + ODBC Driver 18). Authenticates with an Azure
AD **service principal** (ActiveDirectoryServicePrincipal) rather than a SQL
login. Supports Always Encrypted with a column master key in Azure Key
Vault, via the ODBC driver's built-in AKV key store provider
(KeyStoreAuthentication=KeyVaultClientSecret) — reusing the *same* service
principal, since it already needs get/unwrapKey on the column master key.
"""

from __future__ import annotations

from collections.abc import Iterable, Sequence

import pandas as pd
import pyodbc

from ..batching import build_or_of_ands_fragment, chunk_rows, safe_batch_size
from .base import Connector

# SQL Server allows ~2100 parameters per statement; stay well clear of that.
AZURE_SQL_MAX_BOUND_PARAMS = 2000


class AzureSqlConnector(Connector):
    def __init__(
        self,
        driver: str,
        server: str,
        database: str,
        client_id: str,
        client_secret: str,
        tenant_id: str | None = None,
        encrypt: bool = True,
        trust_server_certificate: bool = False,
        always_encrypted: bool = False,
    ) -> None:
        self.driver = driver
        self.server = server
        self.database = database
        self.client_id = client_id
        self.client_secret = client_secret
        self.tenant_id = tenant_id
        self.encrypt = encrypt
        self.trust_server_certificate = trust_server_certificate
        self.always_encrypted = always_encrypted
        self._conn: pyodbc.Connection | None = None

    def _uid(self) -> str:
        # ActiveDirectoryServicePrincipal accepts "<client_id>@<tenant_id>"
        # when the app registration's tenant needs to be made explicit.
        return f"{self.client_id}@{self.tenant_id}" if self.tenant_id else self.client_id

    def _connection_string(self) -> str:
        parts = [
            f"DRIVER={{{self.driver}}}",
            f"SERVER={self.server}",
            f"DATABASE={self.database}",
            f"Encrypt={'yes' if self.encrypt else 'no'}",
            f"TrustServerCertificate={'yes' if self.trust_server_certificate else 'no'}",
            "Authentication=ActiveDirectoryServicePrincipal",
            f"UID={self._uid()}",
            f"PWD={self.client_secret}",
        ]
        if self.always_encrypted:
            parts += [
                "ColumnEncryption=Enabled",
                "KeyStoreAuthentication=KeyVaultClientSecret",
                f"KeyStorePrincipalId={self.client_id}",
                f"KeyStoreSecret={self.client_secret}",
            ]
        return ";".join(parts)

    def connect(self) -> None:
        self._conn = pyodbc.connect(self._connection_string())

    def close(self) -> None:
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    def _require_conn(self) -> pyodbc.Connection:
        if self._conn is None:
            raise RuntimeError("AzureSqlConnector used before connect()")
        return self._conn

    def run_query(self, query: str) -> pd.DataFrame:
        cursor = self._require_conn().cursor()
        try:
            cursor.execute(query)
            columns = [col[0] for col in cursor.description]
            return pd.DataFrame((tuple(row) for row in cursor.fetchall()), columns=columns)
        finally:
            cursor.close()

    def fetch_by_keys(
        self,
        query_template: str,
        key_columns: Sequence[str],
        key_values: Iterable[Sequence],
        key_batch_size: int,
    ) -> pd.DataFrame:
        batch_size = safe_batch_size(key_batch_size, len(key_columns), AZURE_SQL_MAX_BOUND_PARAMS)
        frames: list[pd.DataFrame] = []
        cursor = self._require_conn().cursor()
        try:
            for batch in chunk_rows(list(key_values), batch_size):
                fragment = build_or_of_ands_fragment(key_columns, len(batch), placeholder="?")
                query = query_template.replace(":keys", fragment)
                bind_values = [value for row in batch for value in row]
                cursor.execute(query, bind_values)
                columns = [col[0] for col in cursor.description]
                frames.append(pd.DataFrame((tuple(row) for row in cursor.fetchall()), columns=columns))
        finally:
            cursor.close()
        if not frames:
            return pd.DataFrame()
        return pd.concat(frames, ignore_index=True)
