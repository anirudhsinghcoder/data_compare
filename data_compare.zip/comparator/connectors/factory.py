"""Builds the right Connector for a role ('source'/'target') from config,
importing the pyodbc-backed connector lazily so mock mode never requires it
to be installed."""

from __future__ import annotations

from pathlib import Path

from ..config import AzureSqlConnectionConfig, ConnectionsConfig, resolve_env
from .base import Connector
from .mock import MockConnector

Role = str  # "source" | "target"


def build_connector(
    name: Role,
    connections: ConnectionsConfig,
    *,
    mock_mode: bool = False,
    mock_csv_path: str | Path | None = None,
) -> Connector:
    if mock_mode:
        if mock_csv_path is None:
            raise ValueError("mock_csv_path is required when mock_mode is True")
        return MockConnector(mock_csv_path)

    config: AzureSqlConnectionConfig = getattr(connections, name)
    from .azure_sql import AzureSqlConnector

    sp = config.service_principal
    return AzureSqlConnector(
        driver=config.driver,
        server=resolve_env(config.server_env),
        database=resolve_env(config.database_env),
        client_id=resolve_env(sp.client_id_env),
        client_secret=resolve_env(sp.client_secret_env),
        tenant_id=resolve_env(sp.tenant_id_env) if sp.tenant_id_env else None,
        encrypt=config.encrypt,
        trust_server_certificate=config.trust_server_certificate,
        always_encrypted=config.always_encrypted.enabled,
    )
